--
-- PostgreSQL database dump
--



SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_table_access_method = "heap";

--
-- Name: categories; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."categories" (
    "category_id" integer CONSTRAINT "categories_categoryid_not_null" NOT NULL,
    "category_name" character varying(100) CONSTRAINT "categories_categoryname_not_null" NOT NULL,
    "description" "text"
);


--
-- Name: customers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."customers" (
    "customer_id" character varying(10) CONSTRAINT "customers_customerid_not_null" NOT NULL,
    "company_name" character varying(255) CONSTRAINT "customers_companyname_not_null" NOT NULL,
    "contact_name" character varying(255),
    "contact_title" character varying(100),
    "address" character varying(255),
    "city" character varying(100),
    "region" character varying(50),
    "postal_code" character varying(20),
    "country" character varying(100),
    "phone" character varying(50)
);


--
-- Name: employee_territories; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."employee_territories" (
    "employee_id" integer CONSTRAINT "employee_territories_employeeid_not_null" NOT NULL,
    "territory_id" integer CONSTRAINT "employee_territories_territoryid_not_null" NOT NULL
);


--
-- Name: employees; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."employees" (
    "employee_id" integer CONSTRAINT "employees_employeeid_not_null" NOT NULL,
    "last_name" character varying(100),
    "first_name" character varying(100),
    "title" character varying(100),
    "birth_date" "date",
    "hire_date" "date",
    "city" character varying(100),
    "country" character varying(100),
    "reports_to" integer
);


--
-- Name: order_details; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."order_details" (
    "order_id" integer CONSTRAINT "order_details_orderid_not_null" NOT NULL,
    "product_id" integer CONSTRAINT "order_details_productid_not_null" NOT NULL,
    "unit_price" numeric(10,2) CONSTRAINT "order_details_unitprice_not_null" NOT NULL,
    "quantity" integer NOT NULL,
    "discount" numeric(4,3)
);


--
-- Name: orders; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."orders" (
    "order_id" integer CONSTRAINT "order_orderid_not_null" NOT NULL,
    "customer_id" character varying(10) CONSTRAINT "order_customerid_not_null" NOT NULL,
    "employee_id" integer CONSTRAINT "order_employeeid_not_null" NOT NULL,
    "order_date" "date",
    "required_date" "date",
    "shipped_date" "date",
    "ship_via" integer,
    "freight" numeric(10,2),
    "ship_name" character varying(255),
    "ship_address" character varying(255),
    "ship_city" character varying(100),
    "ship_region" character varying(50),
    "ship_postal_code" character varying(20),
    "ship_country" character varying(100)
);


--
-- Name: products; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."products" (
    "product_id" integer CONSTRAINT "product_productid_not_null" NOT NULL,
    "product_name" character varying(255) CONSTRAINT "product_productname_not_null" NOT NULL,
    "supplier_id" integer,
    "category_id" integer,
    "quantity_per_unit" character varying(100),
    "unit_price" numeric(10,2) CONSTRAINT "product_unitprice_not_null" NOT NULL,
    "units_in_stock" integer,
    "units_on_order" integer,
    "reorder_level" integer,
    "discontinued" integer DEFAULT 0
);


--
-- Name: regions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."regions" (
    "region_id" integer CONSTRAINT "regions_regionid_not_null" NOT NULL,
    "region_description" character varying(100) CONSTRAINT "regions_regiondescription_not_null" NOT NULL
);


--
-- Name: shippers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."shippers" (
    "shipper_id" integer CONSTRAINT "shippers_shipperid_not_null" NOT NULL,
    "company_name" character varying(255),
    "phone" character varying(50)
);


--
-- Name: suppliers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."suppliers" (
    "supplier_id" integer CONSTRAINT "suppliers_supplierid_not_null" NOT NULL,
    "company_name" character varying(255) CONSTRAINT "suppliers_companyname_not_null" NOT NULL,
    "contact_name" character varying(255),
    "country" character varying(100),
    "city" character varying(100),
    "phone" character varying(50),
    "address" character varying(255)
);


--
-- Name: territories; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."territories" (
    "territory_id" integer CONSTRAINT "territories_territoryid_not_null" NOT NULL,
    "territory_description" character varying(100),
    "region_id" integer
);


--
-- Data for Name: categories; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO "public"."categories" ("category_id", "category_name", "description") VALUES (1, 'Beverages', 'Coffees, teas, juices, sodas, beers');
INSERT INTO "public"."categories" ("category_id", "category_name", "description") VALUES (2, 'Condiments', 'Sauces, relishes, spreads, seasonings');
INSERT INTO "public"."categories" ("category_id", "category_name", "description") VALUES (3, 'Confections', 'Desserts, candies, sweet breads');
INSERT INTO "public"."categories" ("category_id", "category_name", "description") VALUES (4, 'Dairy Products', 'Milk, cheese, yogurt, butter');
INSERT INTO "public"."categories" ("category_id", "category_name", "description") VALUES (5, 'Grains/Cereals', 'Breads, pasta, cereals, crackers');
INSERT INTO "public"."categories" ("category_id", "category_name", "description") VALUES (6, 'Meat/Poultry', 'Prepared and cured meats');
INSERT INTO "public"."categories" ("category_id", "category_name", "description") VALUES (7, 'Produce', 'Fresh and dried fruits, vegetables');
INSERT INTO "public"."categories" ("category_id", "category_name", "description") VALUES (8, 'Seafood', 'Fish, shellfish, seaweed');


--
-- Data for Name: customers; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO "public"."customers" ("customer_id", "company_name", "contact_name", "contact_title", "address", "city", "region", "postal_code", "country", "phone") VALUES ('BLU001', 'Riviera Distributors', 'Alexander Garcia', 'Purchasing Manager', '701 Elm St', 'Cologne', NULL, '30471', 'Germany', '+49 637-200-1831');
INSERT INTO "public"."customers" ("customer_id", "company_name", "contact_name", "contact_title", "address", "city", "region", "postal_code", "country", "phone") VALUES ('PAC002', 'Timber Provisioners', 'Isabella Lemaire', 'Purchasing Manager', '668 Queen St', 'Monterrey', NULL, '63045', 'Mexico', '+52 773-796-2702');
INSERT INTO "public"."customers" ("customer_id", "company_name", "contact_name", "contact_title", "address", "city", "region", "postal_code", "country", "phone") VALUES ('GRA003', 'Evergreen Grocers', 'Sara Costa', 'Sales Manager', '383 King St', 'Berlin', NULL, '65155', 'Germany', '+49 369-390-7733');
INSERT INTO "public"."customers" ("customer_id", "company_name", "contact_name", "contact_title", "address", "city", "region", "postal_code", "country", "phone") VALUES ('ALF004', 'Sequoia Gourmet', 'Alexander Dubois', 'Owner', '474 Queen St', 'Rome', NULL, '42281', 'Italy', '+39 917-947-8854');
INSERT INTO "public"."customers" ("customer_id", "company_name", "contact_name", "contact_title", "address", "city", "region", "postal_code", "country", "phone") VALUES ('JUN005', 'Oakridge Markets', 'Sebastian Marin', 'Sales Manager', '863 King St', 'New York', NULL, '83750', 'USA', '+1 767-904-6548');
INSERT INTO "public"."customers" ("customer_id", "company_name", "contact_name", "contact_title", "address", "city", "region", "postal_code", "country", "phone") VALUES ('BLU006', 'Lakeside Trading', 'Diego Rossi', 'Director', '831 Pine Ave', 'São Paulo', NULL, '65230', 'Brazil', '+55 281-207-2193');
INSERT INTO "public"."customers" ("customer_id", "company_name", "contact_name", "contact_title", "address", "city", "region", "postal_code", "country", "phone") VALUES ('MON007', 'Evergreen Delicatessen', 'Chloe Costa', 'Owner', '791 Maple Rd', 'Rosario', NULL, '78902', 'Argentina', '+54 337-742-9605');
INSERT INTO "public"."customers" ("customer_id", "company_name", "contact_name", "contact_title", "address", "city", "region", "postal_code", "country", "phone") VALUES ('KIW008', 'Timber Provisioners', 'Sara Bernard', 'Sales Manager', '355 Queen St', 'Porto', NULL, '73031', 'Portugal', '+351 340-204-1864');
INSERT INTO "public"."customers" ("customer_id", "company_name", "contact_name", "contact_title", "address", "city", "region", "postal_code", "country", "phone") VALUES ('LAK009', 'Blue River Grocers', 'Mateo Bernard', 'Purchasing Manager', '711 Queen St', 'Amsterdam', NULL, '62351', 'Netherlands', '+31 928-283-5080');
INSERT INTO "public"."customers" ("customer_id", "company_name", "contact_name", "contact_title", "address", "city", "region", "postal_code", "country", "phone") VALUES ('PAC010', 'Quartz Trading', 'Victoria Dubois', 'Sales Manager', '368 Queen St', 'Amsterdam', NULL, '76182', 'Netherlands', '+31 549-330-2095');
INSERT INTO "public"."customers" ("customer_id", "company_name", "contact_name", "contact_title", "address", "city", "region", "postal_code", "country", "phone") VALUES ('PAC011', 'Monarch Markets', 'Emma Bernard', 'Director', '895 Maple Rd', 'Monterrey', NULL, '21567', 'Mexico', '+52 554-574-1237');
INSERT INTO "public"."customers" ("customer_id", "company_name", "contact_name", "contact_title", "address", "city", "region", "postal_code", "country", "phone") VALUES ('WIL012', 'Lakeside Markets', 'Isabella Santos', 'Director', '756 King St', 'Paris', NULL, '54715', 'France', '+33 339-133-4025');
INSERT INTO "public"."customers" ("customer_id", "company_name", "contact_name", "contact_title", "address", "city", "region", "postal_code", "country", "phone") VALUES ('GRA013', 'Valley Wholesalers', 'Camila Bernard', 'Owner', '366 Queen St', 'Sevilla', NULL, '26388', 'Spain', '+34 465-657-6091');
INSERT INTO "public"."customers" ("customer_id", "company_name", "contact_name", "contact_title", "address", "city", "region", "postal_code", "country", "phone") VALUES ('GRA014', 'Blue River Foods', 'Julia Dubois', 'Owner', '624 Maple Rd', 'Munich', NULL, '77556', 'Germany', '+49 509-821-9184');
INSERT INTO "public"."customers" ("customer_id", "company_name", "contact_name", "contact_title", "address", "city", "region", "postal_code", "country", "phone") VALUES ('FRO015', 'Lakeside Imports', 'Isabella Costa', 'Director', '764 Maple Rd', 'Hamburg', NULL, '25330', 'Germany', '+49 175-467-9350');
INSERT INTO "public"."customers" ("customer_id", "company_name", "contact_name", "contact_title", "address", "city", "region", "postal_code", "country", "phone") VALUES ('GRA016', 'Inverness Foods', 'Alexander Rossi', 'Sales Manager', '189 Oak St', 'Helsinki', NULL, '20800', 'Finland', '+358 532-937-8348');
INSERT INTO "public"."customers" ("customer_id", "company_name", "contact_name", "contact_title", "address", "city", "region", "postal_code", "country", "phone") VALUES ('WIL017', 'Blue River Provisioners', 'Emma Rossi', 'Sales Manager', '979 King St', 'Guadalajara', NULL, '61456', 'Mexico', '+52 953-964-6444');
INSERT INTO "public"."customers" ("customer_id", "company_name", "contact_name", "contact_title", "address", "city", "region", "postal_code", "country", "phone") VALUES ('CIT018', 'Kiwi Gourmet', 'Ava Rossi', 'Owner', '465 Maple Rd', 'Gothenburg', NULL, '75547', 'Sweden', '+46 133-945-4352');
INSERT INTO "public"."customers" ("customer_id", "company_name", "contact_name", "contact_title", "address", "city", "region", "postal_code", "country", "phone") VALUES ('WIL019', 'Juniper Grocers', 'Isabella Weber', 'Director', '379 Oak St', 'Aarhus', NULL, '80043', 'Denmark', '+45 986-135-8715');
INSERT INTO "public"."customers" ("customer_id", "company_name", "contact_name", "contact_title", "address", "city", "region", "postal_code", "country", "phone") VALUES ('KIW020', 'Harbor Wholesalers', 'Julia Santos', 'Sales Manager', '942 Oak St', 'Barcelona', NULL, '35806', 'Spain', '+34 593-907-6420');
INSERT INTO "public"."customers" ("customer_id", "company_name", "contact_name", "contact_title", "address", "city", "region", "postal_code", "country", "phone") VALUES ('OAK021', 'Inverness Provisioners', 'Elena Schneider', 'Owner', '676 Maple Rd', 'Porto', NULL, '71077', 'Portugal', '+351 992-725-6277');
INSERT INTO "public"."customers" ("customer_id", "company_name", "contact_name", "contact_title", "address", "city", "region", "postal_code", "country", "phone") VALUES ('HAR022', 'Blue River Grocers', 'Alexander Moreau', 'Director', '703 King St', 'Helsinki', NULL, '45744', 'Finland', '+358 340-895-5760');
INSERT INTO "public"."customers" ("customer_id", "company_name", "contact_name", "contact_title", "address", "city", "region", "postal_code", "country", "phone") VALUES ('WIL023', 'Natura Foods', 'Diego Bianchi', 'Owner', '387 Maple Rd', 'Milan', NULL, '92925', 'Italy', '+39 272-452-3102');
INSERT INTO "public"."customers" ("customer_id", "company_name", "contact_name", "contact_title", "address", "city", "region", "postal_code", "country", "phone") VALUES ('NAT024', 'Evergreen Grocers', 'Leonardo Martin', 'Purchasing Manager', '637 Oak St', 'Valencia', NULL, '48889', 'Spain', '+34 702-708-1805');
INSERT INTO "public"."customers" ("customer_id", "company_name", "contact_name", "contact_title", "address", "city", "region", "postal_code", "country", "phone") VALUES ('TIM025', 'Oakridge Trading', 'Ava Silva', 'Sales Manager', '647 Queen St', 'Copenhagen', NULL, '31138', 'Denmark', '+45 140-202-4987');
INSERT INTO "public"."customers" ("customer_id", "company_name", "contact_name", "contact_title", "address", "city", "region", "postal_code", "country", "phone") VALUES ('GRA026', 'Citrus Grocers', 'Leonardo Moreau', 'Purchasing Manager', '106 King St', 'Bristol', NULL, '78705', 'UK', '+44 720-772-4883');
INSERT INTO "public"."customers" ("customer_id", "company_name", "contact_name", "contact_title", "address", "city", "region", "postal_code", "country", "phone") VALUES ('EVE027', 'Harbor Distributors', 'Ava Romero', 'Purchasing Manager', '605 Pine Ave', 'Nice', NULL, '62404', 'France', '+33 730-599-6094');
INSERT INTO "public"."customers" ("customer_id", "company_name", "contact_name", "contact_title", "address", "city", "region", "postal_code", "country", "phone") VALUES ('ZEN028', 'Timber Grocers', 'Diego Dubois', 'Purchasing Manager', '244 Pine Ave', 'Guadalajara', NULL, '98083', 'Mexico', '+52 617-249-4233');
INSERT INTO "public"."customers" ("customer_id", "company_name", "contact_name", "contact_title", "address", "city", "region", "postal_code", "country", "phone") VALUES ('HAR029', 'Pacific Foods', 'Olivia Schneider', 'Purchasing Manager', '727 Elm St', 'Milan', NULL, '75384', 'Italy', '+39 884-742-7638');
INSERT INTO "public"."customers" ("customer_id", "company_name", "contact_name", "contact_title", "address", "city", "region", "postal_code", "country", "phone") VALUES ('UMB030', 'Harbor Gourmet', 'Camila Costa', 'Owner', '819 Pine Ave', 'Rosario', NULL, '42964', 'Argentina', '+54 404-372-4867');
INSERT INTO "public"."customers" ("customer_id", "company_name", "contact_name", "contact_title", "address", "city", "region", "postal_code", "country", "phone") VALUES ('GRA031', 'Alfredo Foods', 'Camila Hernandez', 'Sales Manager', '509 Elm St', 'Barcelona', NULL, '34315', 'Spain', '+34 430-616-2180');
INSERT INTO "public"."customers" ("customer_id", "company_name", "contact_name", "contact_title", "address", "city", "region", "postal_code", "country", "phone") VALUES ('JUN032', 'Delta Wholesalers', 'Sebastian Garcia', 'Purchasing Manager', '281 Pine Ave', 'Monterrey', NULL, '26678', 'Mexico', '+52 931-866-8663');
INSERT INTO "public"."customers" ("customer_id", "company_name", "contact_name", "contact_title", "address", "city", "region", "postal_code", "country", "phone") VALUES ('WIL033', 'Pacific Wholesalers', 'Benjamin Fernandez', 'Owner', '246 Pine Ave', 'Copenhagen', NULL, '43357', 'Denmark', '+45 687-639-2511');
INSERT INTO "public"."customers" ("customer_id", "company_name", "contact_name", "contact_title", "address", "city", "region", "postal_code", "country", "phone") VALUES ('UMB034', 'Willow Markets', 'Benjamin Romero', 'Director', '406 Oak St', 'Paris', NULL, '33381', 'France', '+33 283-764-6445');
INSERT INTO "public"."customers" ("customer_id", "company_name", "contact_name", "contact_title", "address", "city", "region", "postal_code", "country", "phone") VALUES ('OAK035', 'Evergreen Delicatessen', 'Sofia Marin', 'Director', '390 Maple Rd', 'Curitiba', NULL, '31100', 'Brazil', '+55 686-475-7479');
INSERT INTO "public"."customers" ("customer_id", "company_name", "contact_name", "contact_title", "address", "city", "region", "postal_code", "country", "phone") VALUES ('VAL036', 'Umbria Trading', 'Alexander Santos', 'Director', '240 Queen St', 'Antwerp', NULL, '88355', 'Belgium', '+32 258-713-6634');
INSERT INTO "public"."customers" ("customer_id", "company_name", "contact_name", "contact_title", "address", "city", "region", "postal_code", "country", "phone") VALUES ('WIL037', 'Alfredo Wholesalers', 'Isabella Romero', 'Owner', '253 Elm St', 'Krakow', NULL, '44015', 'Poland', '+48 922-377-3987');
INSERT INTO "public"."customers" ("customer_id", "company_name", "contact_name", "contact_title", "address", "city", "region", "postal_code", "country", "phone") VALUES ('VAL038', 'Umbria Grocers', 'Sofia Hernandez', 'Purchasing Manager', '187 Queen St', 'Lisbon', NULL, '46242', 'Portugal', '+351 660-585-1922');
INSERT INTO "public"."customers" ("customer_id", "company_name", "contact_name", "contact_title", "address", "city", "region", "postal_code", "country", "phone") VALUES ('INV039', 'Willow Markets', 'Sara Dubois', 'Owner', '247 Queen St', 'Espoo', NULL, '67430', 'Finland', '+358 409-194-7003');
INSERT INTO "public"."customers" ("customer_id", "company_name", "contact_name", "contact_title", "address", "city", "region", "postal_code", "country", "phone") VALUES ('INV040', 'Oakridge Delicatessen', 'Elena Gonzalez', 'Owner', '66 Oak St', 'Naples', NULL, '29429', 'Italy', '+39 886-538-4753');


--
-- Data for Name: employee_territories; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO "public"."employee_territories" ("employee_id", "territory_id") VALUES (1, 10003);
INSERT INTO "public"."employee_territories" ("employee_id", "territory_id") VALUES (2, 10003);
INSERT INTO "public"."employee_territories" ("employee_id", "territory_id") VALUES (2, 10002);
INSERT INTO "public"."employee_territories" ("employee_id", "territory_id") VALUES (2, 10006);
INSERT INTO "public"."employee_territories" ("employee_id", "territory_id") VALUES (3, 10004);
INSERT INTO "public"."employee_territories" ("employee_id", "territory_id") VALUES (4, 10010);
INSERT INTO "public"."employee_territories" ("employee_id", "territory_id") VALUES (5, 10000);
INSERT INTO "public"."employee_territories" ("employee_id", "territory_id") VALUES (6, 10008);
INSERT INTO "public"."employee_territories" ("employee_id", "territory_id") VALUES (6, 10004);
INSERT INTO "public"."employee_territories" ("employee_id", "territory_id") VALUES (7, 10011);
INSERT INTO "public"."employee_territories" ("employee_id", "territory_id") VALUES (8, 10003);
INSERT INTO "public"."employee_territories" ("employee_id", "territory_id") VALUES (9, 10000);
INSERT INTO "public"."employee_territories" ("employee_id", "territory_id") VALUES (9, 10011);
INSERT INTO "public"."employee_territories" ("employee_id", "territory_id") VALUES (9, 10010);
INSERT INTO "public"."employee_territories" ("employee_id", "territory_id") VALUES (10, 10008);
INSERT INTO "public"."employee_territories" ("employee_id", "territory_id") VALUES (10, 10010);
INSERT INTO "public"."employee_territories" ("employee_id", "territory_id") VALUES (10, 10001);


--
-- Data for Name: employees; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO "public"."employees" ("employee_id", "last_name", "first_name", "title", "birth_date", "hire_date", "city", "country", "reports_to") VALUES (1, 'Hernandez', 'Olivia', 'VP Sales', '1961-10-29', '1997-06-26', 'Toronto', 'Spain', NULL);
INSERT INTO "public"."employees" ("employee_id", "last_name", "first_name", "title", "birth_date", "hire_date", "city", "country", "reports_to") VALUES (2, 'Fernandez', 'Sara', 'Sales Manager', '1968-08-28', '1995-03-31', 'Seattle', 'Italy', NULL);
INSERT INTO "public"."employees" ("employee_id", "last_name", "first_name", "title", "birth_date", "hire_date", "city", "country", "reports_to") VALUES (3, 'Hernandez', 'Noah', 'Sales Coordinator', '1982-08-12', '1996-09-10', 'Madrid', 'Italy', 1);
INSERT INTO "public"."employees" ("employee_id", "last_name", "first_name", "title", "birth_date", "hire_date", "city", "country", "reports_to") VALUES (4, 'Bianchi', 'Isabella', 'Sales Manager', '1983-03-01', '1997-06-28', 'London', 'Canada', 3);
INSERT INTO "public"."employees" ("employee_id", "last_name", "first_name", "title", "birth_date", "hire_date", "city", "country", "reports_to") VALUES (5, 'Hernandez', 'Chloe', 'Sales Manager', '1988-02-04', '1995-09-05', 'Berlin', 'Canada', 2);
INSERT INTO "public"."employees" ("employee_id", "last_name", "first_name", "title", "birth_date", "hire_date", "city", "country", "reports_to") VALUES (6, 'Bianchi', 'Julia', 'Account Executive', '1965-09-01', '1995-05-22', 'London', 'USA', NULL);
INSERT INTO "public"."employees" ("employee_id", "last_name", "first_name", "title", "birth_date", "hire_date", "city", "country", "reports_to") VALUES (7, 'Santos', 'Sebastian', 'Account Executive', '1964-10-08', '1997-06-17', 'Paris', 'Canada', 1);
INSERT INTO "public"."employees" ("employee_id", "last_name", "first_name", "title", "birth_date", "hire_date", "city", "country", "reports_to") VALUES (8, 'Weber', 'Benjamin', 'Sales Coordinator', '1961-11-17', '1997-08-20', 'Madrid', 'France', NULL);
INSERT INTO "public"."employees" ("employee_id", "last_name", "first_name", "title", "birth_date", "hire_date", "city", "country", "reports_to") VALUES (9, 'Marin', 'Nicolas', 'Account Executive', '1989-05-31', '1994-08-06', 'London', 'Italy', 5);
INSERT INTO "public"."employees" ("employee_id", "last_name", "first_name", "title", "birth_date", "hire_date", "city", "country", "reports_to") VALUES (10, 'Moreau', 'Sebastian', 'Sales Manager', '1979-11-11', '1997-04-19', 'Rome', 'Germany', 6);


--
-- Data for Name: order_details; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (1, 53, 32.49, 17, 0.050);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (1, 18, 41.12, 1, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (1, 13, 9.42, 7, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (2, 11, 101.47, 3, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (2, 58, 52.29, 6, 0.150);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (2, 13, 9.42, 14, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (3, 25, 77.35, 18, 0.100);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (3, 8, 43.18, 2, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (3, 10, 43.13, 12, 0.050);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (3, 64, 86.20, 5, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (3, 24, 74.70, 13, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (4, 25, 77.35, 18, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (4, 57, 31.08, 13, 0.050);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (4, 48, 55.03, 20, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (4, 13, 9.42, 17, 0.150);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (5, 49, 25.43, 10, 0.050);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (5, 19, 85.57, 13, 0.050);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (5, 8, 43.18, 7, 0.050);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (6, 40, 18.72, 11, 0.150);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (6, 62, 10.68, 1, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (6, 5, 12.80, 19, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (6, 14, 57.47, 13, 0.150);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (7, 11, 101.47, 19, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (7, 10, 43.13, 5, 0.050);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (7, 45, 46.36, 2, 0.050);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (7, 28, 50.23, 16, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (8, 57, 31.08, 1, 0.100);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (8, 62, 10.68, 16, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (8, 9, 45.34, 5, 0.100);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (8, 13, 9.42, 20, 0.150);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (9, 35, 36.78, 12, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (9, 53, 32.49, 9, 0.100);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (9, 16, 42.45, 20, 0.050);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (10, 24, 74.70, 5, 0.100);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (10, 55, 3.63, 17, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (10, 6, 88.48, 10, 0.100);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (10, 50, 48.31, 16, 0.100);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (10, 41, 94.82, 15, 0.050);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (11, 22, 64.40, 17, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (11, 26, 69.69, 1, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (11, 8, 43.18, 11, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (11, 7, 110.00, 13, 0.100);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (11, 46, 43.93, 14, 0.050);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (12, 52, 107.45, 17, 0.150);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (12, 40, 18.72, 1, 0.150);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (12, 31, 90.59, 5, 0.150);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (12, 22, 64.40, 5, 0.150);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (13, 1, 66.82, 2, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (13, 39, 80.37, 18, 0.100);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (13, 40, 18.72, 3, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (13, 31, 90.59, 18, 0.150);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (13, 48, 55.03, 15, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (14, 54, 117.09, 9, 0.150);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (14, 11, 101.47, 2, 0.050);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (14, 26, 69.69, 16, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (14, 48, 55.03, 1, 0.050);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (14, 9, 45.34, 14, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (15, 55, 3.63, 11, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (15, 17, 88.85, 15, 0.050);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (16, 2, 111.79, 10, 0.100);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (16, 40, 18.72, 16, 0.150);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (16, 10, 43.13, 1, 0.150);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (16, 22, 64.40, 4, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (16, 29, 7.90, 12, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (17, 52, 107.45, 8, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (17, 51, 24.53, 4, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (17, 57, 31.08, 11, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (17, 55, 3.63, 7, 0.100);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (18, 22, 64.40, 17, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (18, 20, 104.98, 20, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (18, 49, 25.43, 1, 0.150);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (19, 11, 101.47, 9, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (19, 15, 101.38, 5, 0.050);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (19, 28, 50.23, 8, 0.050);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (20, 38, 41.73, 1, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (20, 47, 78.65, 8, 0.150);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (20, 27, 18.74, 9, 0.100);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (20, 5, 12.80, 15, 0.150);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (21, 9, 45.34, 1, 0.150);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (21, 43, 67.37, 9, 0.100);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (21, 3, 8.03, 3, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (21, 37, 52.00, 14, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (22, 49, 25.43, 6, 0.150);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (22, 4, 91.70, 1, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (22, 64, 86.20, 4, 0.050);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (23, 3, 8.03, 15, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (23, 61, 39.05, 15, 0.100);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (23, 49, 25.43, 1, 0.100);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (23, 25, 77.35, 3, 0.100);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (24, 20, 104.98, 17, 0.050);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (24, 42, 41.30, 8, 0.050);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (24, 43, 67.37, 10, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (24, 51, 24.53, 11, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (25, 10, 43.13, 1, 0.100);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (25, 30, 38.59, 19, 0.150);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (26, 13, 9.42, 13, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (26, 53, 32.49, 6, 0.150);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (27, 8, 43.18, 16, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (27, 29, 7.90, 1, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (27, 49, 25.43, 1, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (27, 31, 90.59, 9, 0.100);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (27, 34, 56.83, 11, 0.100);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (28, 52, 107.45, 14, 0.100);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (28, 49, 25.43, 15, 0.150);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (28, 58, 52.29, 1, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (29, 23, 104.28, 1, 0.050);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (29, 59, 17.28, 4, 0.150);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (29, 33, 19.29, 9, 0.150);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (29, 4, 91.70, 2, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (29, 16, 42.45, 8, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (30, 45, 46.36, 7, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (30, 63, 108.01, 9, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (30, 64, 86.20, 8, 0.100);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (30, 14, 57.47, 16, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (31, 23, 104.28, 2, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (31, 25, 77.35, 14, 0.150);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (31, 53, 32.49, 20, 0.150);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (32, 12, 46.12, 7, 0.150);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (32, 49, 25.43, 18, 0.050);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (32, 64, 86.20, 2, 0.050);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (32, 60, 105.38, 11, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (33, 2, 111.79, 16, 0.050);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (33, 60, 105.38, 9, 0.050);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (33, 59, 17.28, 15, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (34, 30, 38.59, 18, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (34, 26, 69.69, 9, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (35, 53, 32.49, 10, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (35, 1, 66.82, 11, 0.050);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (35, 47, 78.65, 5, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (35, 43, 67.37, 14, 0.050);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (36, 36, 72.36, 16, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (36, 23, 104.28, 9, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (36, 18, 41.12, 3, 0.050);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (36, 35, 36.78, 11, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (36, 24, 74.70, 2, 0.100);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (37, 41, 94.82, 3, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (37, 26, 69.69, 20, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (37, 48, 55.03, 10, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (37, 27, 18.74, 3, 0.150);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (37, 14, 57.47, 5, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (38, 12, 46.12, 16, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (38, 58, 52.29, 3, 0.150);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (38, 55, 3.63, 10, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (38, 64, 86.20, 7, 0.050);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (39, 33, 19.29, 19, 0.150);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (39, 26, 69.69, 16, 0.050);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (39, 10, 43.13, 6, 0.100);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (39, 27, 18.74, 20, 0.100);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (40, 20, 104.98, 11, 0.100);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (40, 36, 72.36, 12, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (40, 40, 18.72, 14, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (40, 60, 105.38, 10, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (41, 43, 67.37, 3, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (41, 40, 18.72, 2, 0.050);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (41, 53, 32.49, 8, 0.150);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (41, 41, 94.82, 17, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (42, 29, 7.90, 6, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (42, 16, 42.45, 13, 0.150);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (42, 27, 18.74, 14, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (43, 5, 12.80, 14, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (43, 23, 104.28, 11, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (44, 60, 105.38, 4, 0.100);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (44, 9, 45.34, 14, 0.050);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (44, 59, 17.28, 10, 0.050);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (44, 63, 108.01, 7, 0.100);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (44, 46, 43.93, 1, 0.150);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (45, 15, 101.38, 10, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (45, 3, 8.03, 19, 0.150);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (46, 30, 38.59, 10, 0.150);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (46, 45, 46.36, 20, 0.150);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (46, 59, 17.28, 2, 0.150);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (47, 64, 86.20, 14, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (47, 58, 52.29, 10, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (47, 57, 31.08, 3, 0.150);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (47, 2, 111.79, 15, 0.100);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (48, 8, 43.18, 7, 0.150);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (48, 10, 43.13, 7, 0.100);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (48, 2, 111.79, 2, 0.050);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (48, 41, 94.82, 12, 0.100);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (49, 29, 7.90, 20, 0.050);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (49, 28, 50.23, 13, 0.150);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (49, 60, 105.38, 3, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (49, 19, 85.57, 17, 0.050);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (50, 10, 43.13, 20, 0.100);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (50, 44, 94.84, 9, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (50, 23, 104.28, 10, 0.100);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (50, 47, 78.65, 20, 0.150);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (51, 59, 17.28, 1, 0.150);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (51, 55, 3.63, 2, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (51, 64, 86.20, 14, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (51, 32, 48.71, 1, 0.050);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (51, 15, 101.38, 7, 0.100);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (52, 7, 110.00, 3, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (52, 41, 94.82, 3, 0.150);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (53, 62, 10.68, 19, 0.050);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (53, 27, 18.74, 11, 0.100);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (54, 15, 101.38, 18, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (54, 48, 55.03, 19, 0.150);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (54, 1, 66.82, 1, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (54, 57, 31.08, 7, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (54, 22, 64.40, 20, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (55, 1, 66.82, 19, 0.050);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (55, 26, 69.69, 1, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (55, 38, 41.73, 1, 0.100);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (55, 33, 19.29, 2, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (56, 58, 52.29, 11, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (56, 14, 57.47, 14, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (57, 35, 36.78, 3, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (57, 26, 69.69, 4, 0.050);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (57, 38, 41.73, 19, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (57, 30, 38.59, 7, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (58, 26, 69.69, 18, 0.100);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (58, 56, 113.33, 19, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (58, 6, 88.48, 20, 0.150);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (59, 2, 111.79, 6, 0.100);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (59, 57, 31.08, 3, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (60, 57, 31.08, 19, 0.150);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (60, 23, 104.28, 5, 0.100);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (60, 46, 43.93, 12, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (60, 38, 41.73, 11, 0.050);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (60, 13, 9.42, 20, 0.150);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (61, 63, 108.01, 16, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (61, 61, 39.05, 20, 0.150);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (62, 11, 101.47, 11, 0.050);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (62, 46, 43.93, 16, 0.100);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (63, 27, 18.74, 6, 0.050);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (63, 22, 64.40, 15, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (63, 21, 74.03, 8, 0.150);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (63, 58, 52.29, 7, 0.100);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (64, 15, 101.38, 9, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (64, 34, 56.83, 9, 0.100);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (64, 21, 74.03, 2, 0.150);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (64, 58, 52.29, 6, 0.050);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (65, 36, 72.36, 14, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (65, 18, 41.12, 15, 0.100);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (65, 22, 64.40, 10, 0.150);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (65, 48, 55.03, 1, 0.100);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (66, 11, 101.47, 18, 0.050);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (66, 5, 12.80, 10, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (66, 58, 52.29, 5, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (66, 17, 88.85, 11, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (66, 18, 41.12, 20, 0.050);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (67, 61, 39.05, 5, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (67, 47, 78.65, 20, 0.150);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (67, 59, 17.28, 17, 0.150);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (68, 41, 94.82, 3, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (68, 1, 66.82, 12, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (68, 64, 86.20, 15, 0.150);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (68, 59, 17.28, 1, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (68, 49, 25.43, 8, 0.100);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (69, 56, 113.33, 17, 0.150);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (69, 4, 91.70, 14, 0.100);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (69, 39, 80.37, 17, 0.050);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (69, 60, 105.38, 14, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (70, 39, 80.37, 20, 0.150);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (70, 57, 31.08, 6, 0.150);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (70, 19, 85.57, 4, 0.150);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (70, 38, 41.73, 9, 0.050);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (71, 53, 32.49, 3, 0.100);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (71, 45, 46.36, 1, 0.100);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (71, 23, 104.28, 10, 0.100);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (71, 50, 48.31, 4, 0.150);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (72, 10, 43.13, 12, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (72, 25, 77.35, 18, 0.100);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (72, 52, 107.45, 14, 0.100);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (72, 4, 91.70, 18, 0.150);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (72, 17, 88.85, 4, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (73, 50, 48.31, 15, 0.100);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (73, 58, 52.29, 16, 0.100);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (73, 61, 39.05, 18, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (74, 38, 41.73, 18, 0.150);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (74, 31, 90.59, 8, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (75, 57, 31.08, 13, 0.050);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (75, 37, 52.00, 15, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (75, 48, 55.03, 15, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (75, 5, 12.80, 10, 0.100);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (76, 55, 3.63, 2, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (76, 42, 41.30, 2, 0.100);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (76, 43, 67.37, 18, 0.100);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (76, 34, 56.83, 8, 0.050);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (76, 21, 74.03, 6, 0.150);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (77, 17, 88.85, 10, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (77, 26, 69.69, 5, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (78, 36, 72.36, 20, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (78, 20, 104.98, 13, 0.100);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (78, 32, 48.71, 3, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (78, 34, 56.83, 17, 0.150);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (79, 11, 101.47, 1, 0.150);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (79, 54, 117.09, 19, 0.050);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (79, 53, 32.49, 3, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (79, 20, 104.98, 3, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (80, 63, 108.01, 10, 0.150);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (80, 32, 48.71, 5, 0.050);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (80, 12, 46.12, 5, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (81, 24, 74.70, 12, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (81, 15, 101.38, 4, 0.150);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (82, 48, 55.03, 6, 0.150);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (82, 22, 64.40, 12, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (82, 50, 48.31, 11, 0.150);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (83, 18, 41.12, 7, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (83, 29, 7.90, 15, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (83, 55, 3.63, 12, 0.150);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (83, 13, 9.42, 15, 0.100);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (83, 14, 57.47, 7, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (84, 6, 88.48, 13, 0.150);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (84, 56, 113.33, 8, 0.100);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (84, 49, 25.43, 8, 0.100);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (85, 52, 107.45, 14, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (85, 20, 104.98, 7, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (85, 47, 78.65, 1, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (85, 46, 43.93, 3, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (85, 56, 113.33, 12, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (86, 60, 105.38, 14, 0.150);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (86, 27, 18.74, 18, 0.150);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (86, 13, 9.42, 15, 0.100);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (87, 13, 9.42, 1, 0.050);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (87, 34, 56.83, 9, 0.150);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (87, 29, 7.90, 5, 0.150);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (87, 3, 8.03, 10, 0.050);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (88, 13, 9.42, 17, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (88, 29, 7.90, 12, 0.100);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (88, 43, 67.37, 11, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (88, 57, 31.08, 14, 0.050);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (89, 28, 50.23, 4, 0.150);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (89, 32, 48.71, 5, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (90, 10, 43.13, 10, 0.100);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (90, 55, 3.63, 1, 0.050);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (91, 48, 55.03, 19, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (91, 25, 77.35, 13, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (91, 24, 74.70, 12, 0.100);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (91, 62, 10.68, 15, 0.150);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (92, 61, 39.05, 13, 0.100);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (92, 47, 78.65, 13, 0.100);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (92, 38, 41.73, 17, 0.050);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (93, 60, 105.38, 5, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (93, 18, 41.12, 7, 0.100);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (93, 30, 38.59, 18, 0.050);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (94, 17, 88.85, 14, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (94, 42, 41.30, 4, 0.100);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (94, 37, 52.00, 13, 0.050);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (94, 56, 113.33, 2, 0.050);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (95, 27, 18.74, 5, 0.050);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (95, 25, 77.35, 19, 0.050);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (95, 41, 94.82, 16, 0.050);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (95, 44, 94.84, 5, 0.150);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (95, 16, 42.45, 3, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (96, 14, 57.47, 7, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (97, 10, 43.13, 1, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (97, 48, 55.03, 5, 0.100);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (98, 51, 24.53, 3, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (98, 10, 43.13, 1, 0.150);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (98, 58, 52.29, 11, 0.050);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (99, 42, 41.30, 10, 0.050);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (99, 43, 67.37, 18, 0.100);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (100, 37, 52.00, 16, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (100, 4, 91.70, 18, 0.050);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (100, 40, 18.72, 16, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (101, 1, 66.82, 9, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (101, 49, 25.43, 4, 0.150);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (101, 50, 48.31, 7, 0.150);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (102, 17, 88.85, 20, 0.150);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (102, 38, 41.73, 15, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (102, 23, 104.28, 19, 0.150);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (103, 5, 12.80, 13, 0.150);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (103, 61, 39.05, 13, 0.050);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (103, 58, 52.29, 15, 0.150);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (103, 2, 111.79, 17, 0.150);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (103, 37, 52.00, 5, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (104, 29, 7.90, 17, 0.100);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (104, 32, 48.71, 9, 0.100);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (105, 8, 43.18, 6, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (105, 60, 105.38, 19, 0.050);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (105, 51, 24.53, 15, 0.050);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (106, 50, 48.31, 2, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (106, 45, 46.36, 9, 0.150);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (106, 52, 107.45, 6, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (106, 38, 41.73, 7, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (106, 3, 8.03, 15, 0.050);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (107, 23, 104.28, 20, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (107, 2, 111.79, 5, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (108, 42, 41.30, 9, 0.050);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (108, 51, 24.53, 6, 0.050);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (108, 7, 110.00, 6, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (108, 20, 104.98, 15, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (108, 1, 66.82, 14, 0.100);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (109, 38, 41.73, 5, 0.150);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (109, 2, 111.79, 1, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (109, 48, 55.03, 6, 0.050);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (109, 54, 117.09, 7, 0.150);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (110, 10, 43.13, 14, 0.050);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (110, 47, 78.65, 6, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (110, 49, 25.43, 17, 0.100);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (111, 58, 52.29, 1, 0.050);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (111, 27, 18.74, 20, 0.050);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (111, 47, 78.65, 11, 0.150);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (111, 57, 31.08, 6, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (111, 50, 48.31, 9, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (112, 17, 88.85, 12, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (112, 39, 80.37, 7, 0.150);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (112, 23, 104.28, 9, 0.150);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (112, 44, 94.84, 6, 0.100);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (113, 21, 74.03, 8, 0.050);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (113, 7, 110.00, 17, 0.150);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (114, 10, 43.13, 10, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (114, 36, 72.36, 4, 0.100);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (114, 41, 94.82, 8, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (114, 7, 110.00, 10, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (115, 30, 38.59, 16, 0.150);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (115, 61, 39.05, 7, 0.100);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (116, 57, 31.08, 9, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (116, 23, 104.28, 3, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (116, 10, 43.13, 11, 0.100);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (116, 43, 67.37, 12, 0.150);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (117, 6, 88.48, 14, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (117, 34, 56.83, 14, 0.150);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (118, 26, 69.69, 19, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (118, 34, 56.83, 7, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (119, 21, 74.03, 1, 0.100);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (119, 33, 19.29, 12, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (120, 44, 94.84, 16, 0.150);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (120, 14, 57.47, 1, 0.100);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (120, 1, 66.82, 12, 0.150);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (121, 19, 85.57, 8, 0.050);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (121, 25, 77.35, 12, 0.150);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (121, 24, 74.70, 8, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (121, 51, 24.53, 1, 0.100);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (122, 63, 108.01, 4, 0.100);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (122, 51, 24.53, 19, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (122, 26, 69.69, 3, 0.150);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (122, 58, 52.29, 4, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (123, 35, 36.78, 11, 0.050);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (123, 34, 56.83, 20, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (124, 12, 46.12, 6, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (124, 11, 101.47, 2, 0.150);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (124, 44, 94.84, 13, 0.100);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (124, 41, 94.82, 3, 0.150);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (124, 54, 117.09, 12, 0.050);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (125, 19, 85.57, 1, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (125, 61, 39.05, 18, 0.050);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (125, 34, 56.83, 9, 0.100);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (125, 31, 90.59, 14, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (126, 47, 78.65, 1, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (126, 40, 18.72, 16, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (127, 44, 94.84, 6, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (127, 4, 91.70, 5, 0.150);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (127, 2, 111.79, 3, 0.050);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (128, 52, 107.45, 7, 0.100);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (128, 30, 38.59, 6, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (129, 5, 12.80, 6, 0.050);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (129, 15, 101.38, 16, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (129, 32, 48.71, 17, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (130, 51, 24.53, 10, 0.050);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (130, 25, 77.35, 15, 0.150);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (131, 19, 85.57, 5, 0.050);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (131, 41, 94.82, 6, 0.150);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (131, 31, 90.59, 8, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (131, 60, 105.38, 5, 0.050);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (132, 43, 67.37, 1, 0.050);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (132, 63, 108.01, 1, 0.100);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (133, 24, 74.70, 7, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (133, 52, 107.45, 12, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (133, 48, 55.03, 5, 0.150);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (134, 23, 104.28, 18, 0.150);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (134, 32, 48.71, 10, 0.100);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (134, 47, 78.65, 16, 0.050);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (134, 19, 85.57, 15, 0.050);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (135, 22, 64.40, 2, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (135, 37, 52.00, 9, 0.150);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (135, 23, 104.28, 18, 0.050);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (135, 60, 105.38, 1, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (135, 61, 39.05, 5, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (136, 41, 94.82, 11, 0.100);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (136, 16, 42.45, 19, 0.100);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (136, 25, 77.35, 14, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (136, 46, 43.93, 3, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (136, 32, 48.71, 4, 0.150);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (137, 63, 108.01, 10, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (137, 43, 67.37, 10, 0.050);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (138, 44, 94.84, 12, 0.100);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (138, 19, 85.57, 13, 0.100);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (138, 33, 19.29, 15, 0.100);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (138, 30, 38.59, 16, 0.100);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (139, 49, 25.43, 10, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (139, 6, 88.48, 2, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (140, 39, 80.37, 12, 0.150);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (140, 62, 10.68, 8, 0.100);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (140, 22, 64.40, 16, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (140, 26, 69.69, 6, 0.050);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (140, 57, 31.08, 6, 0.100);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (141, 25, 77.35, 15, 0.100);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (141, 57, 31.08, 14, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (141, 28, 50.23, 10, 0.050);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (141, 30, 38.59, 12, 0.100);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (142, 19, 85.57, 20, 0.150);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (142, 44, 94.84, 12, 0.150);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (142, 58, 52.29, 19, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (143, 40, 18.72, 18, 0.050);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (143, 36, 72.36, 16, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (143, 30, 38.59, 17, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (143, 38, 41.73, 3, 0.150);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (144, 22, 64.40, 20, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (144, 26, 69.69, 3, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (145, 49, 25.43, 2, 0.100);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (145, 61, 39.05, 3, 0.150);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (145, 56, 113.33, 7, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (145, 57, 31.08, 15, 0.100);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (146, 63, 108.01, 19, 0.150);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (146, 48, 55.03, 14, 0.050);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (146, 34, 56.83, 3, 0.050);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (147, 60, 105.38, 18, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (147, 5, 12.80, 11, 0.100);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (148, 22, 64.40, 2, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (148, 13, 9.42, 19, 0.050);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (149, 11, 101.47, 1, 0.100);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (149, 35, 36.78, 14, 0.100);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (150, 5, 12.80, 4, 0.050);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (150, 21, 74.03, 19, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (151, 40, 18.72, 7, 0.150);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (151, 35, 36.78, 15, 0.100);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (152, 20, 104.98, 4, 0.100);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (152, 47, 78.65, 13, 0.100);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (152, 15, 101.38, 5, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (153, 33, 19.29, 2, 0.050);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (153, 49, 25.43, 18, 0.100);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (153, 46, 43.93, 9, 0.050);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (153, 51, 24.53, 8, 0.150);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (153, 7, 110.00, 8, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (154, 60, 105.38, 15, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (154, 35, 36.78, 15, 0.050);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (154, 28, 50.23, 5, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (155, 45, 46.36, 4, 0.150);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (155, 26, 69.69, 20, 0.050);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (155, 4, 91.70, 18, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (155, 35, 36.78, 20, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (156, 17, 88.85, 2, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (156, 14, 57.47, 16, 0.100);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (157, 43, 67.37, 20, 0.150);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (157, 63, 108.01, 10, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (157, 58, 52.29, 12, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (157, 4, 91.70, 19, 0.050);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (157, 28, 50.23, 19, 0.100);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (158, 35, 36.78, 5, 0.150);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (158, 15, 101.38, 6, 0.050);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (158, 9, 45.34, 15, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (158, 60, 105.38, 15, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (159, 52, 107.45, 4, 0.050);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (159, 21, 74.03, 10, 0.100);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (159, 36, 72.36, 18, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (160, 50, 48.31, 1, 0.100);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (160, 61, 39.05, 18, 0.100);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (160, 43, 67.37, 5, 0.100);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (160, 39, 80.37, 3, 0.100);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (161, 38, 41.73, 20, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (161, 18, 41.12, 6, 0.050);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (161, 52, 107.45, 1, 0.150);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (162, 43, 67.37, 19, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (162, 8, 43.18, 19, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (162, 44, 94.84, 8, 0.100);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (162, 10, 43.13, 19, 0.050);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (162, 21, 74.03, 16, 0.100);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (163, 25, 77.35, 12, 0.100);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (163, 37, 52.00, 12, 0.150);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (163, 62, 10.68, 5, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (163, 20, 104.98, 3, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (163, 17, 88.85, 8, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (164, 5, 12.80, 10, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (164, 16, 42.45, 17, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (164, 21, 74.03, 3, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (164, 48, 55.03, 17, 0.100);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (164, 33, 19.29, 9, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (165, 41, 94.82, 20, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (165, 42, 41.30, 1, 0.050);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (165, 48, 55.03, 18, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (165, 23, 104.28, 7, 0.100);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (166, 55, 3.63, 4, 0.150);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (166, 19, 85.57, 6, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (166, 46, 43.93, 17, 0.150);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (166, 18, 41.12, 4, 0.150);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (166, 8, 43.18, 5, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (167, 11, 101.47, 16, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (167, 64, 86.20, 20, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (167, 33, 19.29, 1, 0.050);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (167, 59, 17.28, 13, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (168, 46, 43.93, 18, 0.100);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (168, 2, 111.79, 2, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (168, 29, 7.90, 14, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (169, 49, 25.43, 2, 0.050);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (169, 63, 108.01, 19, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (169, 4, 91.70, 2, 0.050);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (170, 62, 10.68, 18, 0.050);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (171, 44, 94.84, 6, 0.150);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (171, 21, 74.03, 18, 0.050);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (172, 59, 17.28, 5, 0.050);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (172, 38, 41.73, 3, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (172, 31, 90.59, 14, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (173, 60, 105.38, 10, 0.100);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (173, 20, 104.98, 8, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (174, 59, 17.28, 19, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (174, 26, 69.69, 16, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (174, 28, 50.23, 15, 0.100);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (174, 29, 7.90, 3, 0.050);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (175, 21, 74.03, 20, 0.150);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (175, 4, 91.70, 12, 0.150);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (176, 41, 94.82, 12, 0.100);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (176, 32, 48.71, 6, 0.150);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (176, 36, 72.36, 1, 0.050);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (177, 54, 117.09, 16, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (177, 53, 32.49, 6, 0.100);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (178, 24, 74.70, 13, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (178, 46, 43.93, 6, 0.150);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (179, 38, 41.73, 13, 0.150);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (179, 6, 88.48, 7, 0.150);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (179, 12, 46.12, 15, 0.050);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (180, 9, 45.34, 7, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (180, 27, 18.74, 18, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (180, 39, 80.37, 15, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (181, 3, 8.03, 13, 0.050);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (181, 53, 32.49, 14, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (181, 21, 74.03, 19, 0.100);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (181, 61, 39.05, 4, 0.050);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (182, 15, 101.38, 15, 0.100);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (182, 63, 108.01, 17, 0.100);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (182, 41, 94.82, 14, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (182, 36, 72.36, 19, 0.050);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (183, 17, 88.85, 13, 0.100);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (183, 16, 42.45, 13, 0.150);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (183, 27, 18.74, 18, 0.050);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (184, 62, 10.68, 3, 0.100);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (184, 9, 45.34, 7, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (184, 4, 91.70, 10, 0.100);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (184, 21, 74.03, 13, 0.150);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (184, 25, 77.35, 20, 0.150);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (185, 24, 74.70, 5, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (185, 9, 45.34, 12, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (185, 58, 52.29, 16, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (186, 46, 43.93, 8, 0.150);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (186, 12, 46.12, 12, 0.150);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (187, 49, 25.43, 2, 0.100);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (187, 54, 117.09, 11, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (188, 61, 39.05, 12, 0.100);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (188, 62, 10.68, 14, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (189, 21, 74.03, 9, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (189, 1, 66.82, 11, 0.150);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (190, 64, 86.20, 17, 0.150);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (190, 51, 24.53, 16, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (190, 34, 56.83, 2, 0.050);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (191, 39, 80.37, 17, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (191, 6, 88.48, 19, 0.150);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (191, 51, 24.53, 10, 0.050);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (191, 61, 39.05, 12, 0.100);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (191, 40, 18.72, 14, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (192, 61, 39.05, 9, 0.150);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (192, 47, 78.65, 4, 0.050);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (192, 11, 101.47, 16, 0.150);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (192, 4, 91.70, 20, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (192, 31, 90.59, 7, 0.050);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (193, 31, 90.59, 20, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (193, 48, 55.03, 15, 0.100);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (193, 36, 72.36, 17, 0.150);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (194, 9, 45.34, 16, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (194, 24, 74.70, 17, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (194, 30, 38.59, 12, 0.050);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (194, 5, 12.80, 17, 0.150);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (195, 3, 8.03, 20, 0.150);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (195, 38, 41.73, 4, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (196, 26, 69.69, 4, 0.050);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (196, 35, 36.78, 8, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (197, 41, 94.82, 2, 0.050);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (197, 39, 80.37, 6, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (197, 20, 104.98, 13, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (197, 47, 78.65, 2, 0.150);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (198, 1, 66.82, 19, 0.100);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (198, 15, 101.38, 13, 0.050);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (199, 45, 46.36, 16, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (199, 1, 66.82, 10, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (200, 51, 24.53, 16, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (200, 44, 94.84, 16, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (200, 48, 55.03, 1, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (200, 24, 74.70, 13, 0.150);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (200, 12, 46.12, 5, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (201, 33, 19.29, 23, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (201, 46, 43.93, 2, 0.150);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (202, 1, 66.82, 15, 0.050);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (202, 4, 91.70, 19, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (202, 37, 52.00, 17, 0.150);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (203, 23, 104.28, 11, 0.150);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (203, 28, 50.23, 19, 0.150);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (203, 42, 41.30, 15, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (203, 47, 78.65, 16, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (204, 35, 36.78, 25, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (205, 15, 101.38, 6, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (205, 21, 74.03, 20, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (206, 3, 8.03, 24, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (206, 5, 12.80, 12, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (206, 11, 101.47, 15, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (207, 2, 111.79, 18, 0.050);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (207, 10, 43.13, 7, 0.150);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (207, 20, 104.98, 7, 0.100);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (207, 54, 117.09, 21, 0.100);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (208, 1, 66.82, 1, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (209, 1, 66.82, 23, 0.050);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (209, 51, 24.53, 19, 0.050);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (210, 50, 48.31, 23, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (210, 62, 10.68, 18, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (210, 63, 108.01, 18, 0.050);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (211, 3, 8.03, 27, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (211, 43, 67.37, 28, 0.100);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (211, 44, 94.84, 26, 0.150);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (211, 47, 78.65, 4, 0.100);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (212, 34, 56.83, 27, 0.050);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (213, 21, 74.03, 16, 0.100);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (213, 43, 67.37, 12, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (214, 11, 101.47, 27, 0.150);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (214, 21, 74.03, 24, 0.100);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (214, 22, 64.40, 17, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (215, 10, 43.13, 5, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (215, 20, 104.98, 15, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (215, 21, 74.03, 15, 0.100);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (215, 41, 94.82, 7, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (216, 42, 41.30, 13, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (217, 30, 38.59, 12, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (217, 50, 48.31, 3, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (218, 4, 91.70, 3, 0.050);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (218, 20, 104.98, 14, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (218, 27, 18.74, 15, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (219, 9, 45.34, 25, 0.150);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (219, 27, 18.74, 6, 0.050);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (219, 37, 52.00, 24, 0.150);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (219, 62, 10.68, 17, 0.100);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (220, 5, 12.80, 18, 0.050);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (221, 3, 8.03, 18, 0.100);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (221, 11, 101.47, 14, 0.150);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (222, 3, 8.03, 23, 0.100);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (222, 27, 18.74, 21, 0.150);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (222, 53, 32.49, 14, 0.150);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (223, 11, 101.47, 23, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (223, 51, 24.53, 8, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (223, 57, 31.08, 16, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (223, 62, 10.68, 12, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (224, 56, 113.33, 8, 0.050);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (225, 9, 45.34, 17, 0.150);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (225, 52, 107.45, 21, 0.050);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (226, 2, 111.79, 7, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (226, 3, 8.03, 17, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (226, 60, 105.38, 25, 0.050);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (227, 3, 8.03, 22, 0.150);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (227, 36, 72.36, 2, 0.100);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (227, 42, 41.30, 26, 0.150);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (227, 46, 43.93, 21, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (228, 54, 117.09, 17, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (229, 44, 94.84, 22, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (229, 48, 55.03, 19, 0.150);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (230, 48, 55.03, 11, 0.150);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (230, 53, 32.49, 25, 0.100);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (230, 59, 17.28, 25, 0.100);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (231, 1, 66.82, 2, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (231, 24, 74.70, 3, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (231, 47, 78.65, 12, 0.150);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (231, 59, 17.28, 7, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (232, 7, 110.00, 2, 0.050);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (233, 28, 50.23, 20, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (233, 59, 17.28, 12, 0.150);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (234, 8, 43.18, 10, 0.100);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (234, 15, 101.38, 9, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (234, 46, 43.93, 12, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (235, 14, 57.47, 19, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (235, 18, 41.12, 9, 0.050);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (235, 33, 19.29, 19, 0.150);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (235, 56, 113.33, 30, 0.050);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (236, 48, 55.03, 23, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (237, 10, 43.13, 14, 0.150);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (237, 11, 101.47, 25, 0.050);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (238, 9, 45.34, 30, 0.050);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (238, 14, 57.47, 21, 0.050);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (238, 52, 107.45, 18, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (239, 1, 66.82, 30, 0.150);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (239, 30, 38.59, 1, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (239, 48, 55.03, 18, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (239, 63, 108.01, 8, 0.050);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (240, 20, 104.98, 24, 0.050);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (241, 9, 45.34, 21, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (241, 44, 94.84, 23, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (242, 34, 56.83, 14, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (242, 46, 43.93, 21, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (242, 57, 31.08, 20, 0.150);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (243, 3, 8.03, 6, 0.100);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (243, 12, 46.12, 10, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (243, 42, 41.30, 20, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (243, 63, 108.01, 25, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (244, 46, 43.93, 23, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (245, 4, 91.70, 16, 0.150);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (245, 15, 101.38, 1, 0.150);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (246, 37, 52.00, 6, 0.050);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (246, 58, 52.29, 12, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (246, 63, 108.01, 21, 0.050);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (247, 4, 91.70, 17, 0.100);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (247, 10, 43.13, 18, 0.050);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (247, 34, 56.83, 15, 0.150);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (247, 46, 43.93, 28, 0.150);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (248, 47, 78.65, 12, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (249, 1, 66.82, 1, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (249, 59, 17.28, 26, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (250, 15, 101.38, 20, 0.050);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (250, 27, 18.74, 26, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (250, 35, 36.78, 3, 0.050);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (251, 35, 36.78, 8, 0.100);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (251, 39, 80.37, 9, 0.150);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (251, 41, 94.82, 20, 0.050);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (251, 47, 78.65, 4, 0.100);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (252, 10, 43.13, 29, 0.050);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (253, 5, 12.80, 16, 0.150);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (253, 62, 10.68, 13, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (254, 8, 43.18, 28, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (254, 26, 69.69, 25, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (254, 40, 18.72, 6, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (255, 7, 110.00, 10, 0.050);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (255, 45, 46.36, 13, 0.150);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (255, 53, 32.49, 18, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (255, 62, 10.68, 1, 0.150);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (256, 59, 17.28, 30, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (257, 24, 74.70, 19, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (257, 47, 78.65, 18, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (258, 37, 52.00, 26, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (258, 43, 67.37, 12, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (258, 63, 108.01, 9, 0.100);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (259, 3, 8.03, 29, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (259, 45, 46.36, 7, 0.100);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (259, 56, 113.33, 20, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (259, 63, 108.01, 5, 0.150);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (260, 63, 108.01, 2, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (261, 39, 80.37, 28, 0.150);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (261, 57, 31.08, 6, 0.150);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (262, 2, 111.79, 28, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (262, 22, 64.40, 2, 0.150);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (262, 30, 38.59, 12, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (263, 8, 43.18, 13, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (263, 9, 45.34, 24, 0.050);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (263, 45, 46.36, 11, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (263, 47, 78.65, 26, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (264, 46, 43.93, 18, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (265, 24, 74.70, 25, 0.050);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (265, 56, 113.33, 16, 0.150);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (266, 22, 64.40, 12, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (266, 42, 41.30, 9, 0.150);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (266, 56, 113.33, 6, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (267, 2, 111.79, 15, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (267, 30, 38.59, 13, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (267, 50, 48.31, 9, 0.050);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (267, 62, 10.68, 11, 0.150);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (268, 54, 117.09, 19, 0.100);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (269, 9, 45.34, 3, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (269, 48, 55.03, 18, 0.100);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (270, 8, 43.18, 22, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (270, 33, 19.29, 8, 0.000);
INSERT INTO "public"."order_details" ("order_id", "product_id", "unit_price", "quantity", "discount") VALUES (270, 50, 48.31, 23, 0.000);


--
-- Data for Name: orders; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (1, 'WIL019', 8, '2023-06-05', '2023-06-23', '2023-06-11', 3, 294.27, 'Juniper Grocers', '379 Oak St', 'Aarhus', NULL, '80043', 'Denmark');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (2, 'PAC011', 8, '2024-10-14', '2024-11-02', '2024-10-16', 3, 70.77, 'Monarch Markets', '895 Maple Rd', 'Monterrey', NULL, '21567', 'Mexico');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (3, 'ZEN028', 1, '2024-01-08', '2024-01-23', '2024-01-19', 2, 323.81, 'Timber Grocers', '244 Pine Ave', 'Guadalajara', NULL, '98083', 'Mexico');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (4, 'GRA014', 6, '2025-02-21', '2025-03-01', '2025-03-03', 1, 89.72, 'Blue River Foods', '624 Maple Rd', 'Munich', NULL, '77556', 'Germany');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (5, 'INV040', 3, '2023-06-20', '2023-06-30', '2023-06-27', 1, 459.72, 'Oakridge Delicatessen', '66 Oak St', 'Naples', NULL, '29429', 'Italy');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (6, 'WIL033', 7, '2024-02-14', '2024-02-23', '2024-02-15', 1, 370.68, 'Pacific Wholesalers', '246 Pine Ave', 'Copenhagen', NULL, '43357', 'Denmark');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (7, 'VAL038', 10, '2023-04-09', '2023-04-17', '2023-04-13', 1, 432.11, 'Umbria Grocers', '187 Queen St', 'Lisbon', NULL, '46242', 'Portugal');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (8, 'HAR022', 6, '2023-02-21', '2023-03-08', '2023-02-28', 3, 481.64, 'Blue River Grocers', '703 King St', 'Helsinki', NULL, '45744', 'Finland');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (9, 'JUN005', 9, '2023-09-28', '2023-10-13', '2023-10-10', 1, 420.64, 'Oakridge Markets', '863 King St', 'New York', NULL, '83750', 'USA');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (10, 'ZEN028', 3, '2023-11-01', '2023-11-11', '2023-11-07', 3, 363.50, 'Timber Grocers', '244 Pine Ave', 'Guadalajara', NULL, '98083', 'Mexico');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (11, 'VAL038', 1, '2023-01-14', '2023-01-30', '2023-01-25', 2, 389.78, 'Umbria Grocers', '187 Queen St', 'Lisbon', NULL, '46242', 'Portugal');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (12, 'KIW008', 1, '2024-10-16', '2024-10-19', '2024-10-26', 3, 33.23, 'Timber Provisioners', '355 Queen St', 'Porto', NULL, '73031', 'Portugal');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (13, 'JUN005', 3, '2025-07-14', '2025-07-21', '2025-07-20', 3, 99.24, 'Oakridge Markets', '863 King St', 'New York', NULL, '83750', 'USA');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (14, 'WIL017', 4, '2023-01-23', '2023-02-02', '2023-01-31', 1, 22.94, 'Blue River Provisioners', '979 King St', 'Guadalajara', NULL, '61456', 'Mexico');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (15, 'WIL033', 4, '2024-09-03', '2024-09-16', '2024-09-12', 1, 347.71, 'Pacific Wholesalers', '246 Pine Ave', 'Copenhagen', NULL, '43357', 'Denmark');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (16, 'JUN032', 8, '2023-05-02', '2023-05-08', '2023-05-09', 1, 233.38, 'Delta Wholesalers', '281 Pine Ave', 'Monterrey', NULL, '26678', 'Mexico');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (17, 'WIL023', 2, '2025-10-19', '2025-11-05', '2025-10-29', 3, 119.33, 'Natura Foods', '387 Maple Rd', 'Milan', NULL, '92925', 'Italy');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (18, 'VAL036', 3, '2023-05-25', '2023-06-04', '2023-05-29', 1, 47.14, 'Umbria Trading', '240 Queen St', 'Antwerp', NULL, '88355', 'Belgium');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (19, 'CIT018', 10, '2023-09-19', '2023-09-25', '2023-09-23', 1, 7.05, 'Kiwi Gourmet', '465 Maple Rd', 'Gothenburg', NULL, '75547', 'Sweden');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (20, 'WIL017', 6, '2024-01-13', '2024-01-19', '2024-01-17', 3, 458.90, 'Blue River Provisioners', '979 King St', 'Guadalajara', NULL, '61456', 'Mexico');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (21, 'BLU001', 2, '2023-07-26', '2023-07-31', '2023-08-08', 3, 347.40, 'Riviera Distributors', '701 Elm St', 'Cologne', NULL, '30471', 'Germany');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (22, 'UMB034', 7, '2023-05-17', '2023-05-31', '2023-05-31', 2, 457.57, 'Willow Markets', '406 Oak St', 'Paris', NULL, '33381', 'France');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (23, 'INV040', 4, '2024-06-13', '2024-07-01', '2024-06-14', 1, 392.27, 'Oakridge Delicatessen', '66 Oak St', 'Naples', NULL, '29429', 'Italy');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (24, 'ALF004', 2, '2025-07-25', '2025-08-12', '2025-08-01', 1, 264.06, 'Sequoia Gourmet', '474 Queen St', 'Rome', NULL, '42281', 'Italy');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (25, 'UMB034', 1, '2023-02-21', '2023-03-07', '2023-03-05', 1, 68.99, 'Willow Markets', '406 Oak St', 'Paris', NULL, '33381', 'France');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (26, 'WIL037', 3, '2023-09-11', '2023-09-22', '2023-09-13', 2, 14.02, 'Alfredo Wholesalers', '253 Elm St', 'Krakow', NULL, '44015', 'Poland');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (27, 'BLU006', 5, '2024-10-23', '2024-10-28', '2024-10-28', 2, 334.53, 'Lakeside Trading', '831 Pine Ave', 'São Paulo', NULL, '65230', 'Brazil');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (28, 'UMB030', 6, '2025-09-08', '2025-09-15', '2025-09-16', 3, 73.25, 'Harbor Gourmet', '819 Pine Ave', 'Rosario', NULL, '42964', 'Argentina');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (29, 'INV040', 9, '2023-09-25', '2023-10-15', '2023-10-07', 3, 451.58, 'Oakridge Delicatessen', '66 Oak St', 'Naples', NULL, '29429', 'Italy');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (30, 'JUN032', 10, '2023-08-14', '2023-08-22', '2023-08-18', 1, 392.82, 'Delta Wholesalers', '281 Pine Ave', 'Monterrey', NULL, '26678', 'Mexico');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (31, 'UMB030', 6, '2025-05-27', '2025-06-01', '2025-06-04', 1, 225.52, 'Harbor Gourmet', '819 Pine Ave', 'Rosario', NULL, '42964', 'Argentina');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (32, 'GRA016', 7, '2023-09-25', '2023-10-08', '2023-10-04', 3, 354.01, 'Inverness Foods', '189 Oak St', 'Helsinki', NULL, '20800', 'Finland');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (33, 'CIT018', 9, '2025-02-09', '2025-02-28', '2025-02-11', 2, 343.08, 'Kiwi Gourmet', '465 Maple Rd', 'Gothenburg', NULL, '75547', 'Sweden');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (34, 'LAK009', 8, '2024-05-27', '2024-06-03', '2024-06-07', 2, 362.74, 'Blue River Grocers', '711 Queen St', 'Amsterdam', NULL, '62351', 'Netherlands');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (35, 'KIW008', 5, '2022-10-13', '2022-10-23', '2022-10-15', 1, 308.08, 'Timber Provisioners', '355 Queen St', 'Porto', NULL, '73031', 'Portugal');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (36, 'VAL038', 5, '2023-11-22', '2023-11-29', '2023-11-28', 3, 221.33, 'Umbria Grocers', '187 Queen St', 'Lisbon', NULL, '46242', 'Portugal');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (37, 'BLU006', 4, '2025-04-20', '2025-05-09', '2025-04-27', 2, 215.53, 'Lakeside Trading', '831 Pine Ave', 'São Paulo', NULL, '65230', 'Brazil');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (38, 'GRA003', 5, '2023-04-02', '2023-04-14', '2023-04-10', 3, 273.02, 'Evergreen Grocers', '383 King St', 'Berlin', NULL, '65155', 'Germany');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (39, 'UMB030', 2, '2023-03-05', '2023-03-14', '2023-03-19', 3, 88.39, 'Harbor Gourmet', '819 Pine Ave', 'Rosario', NULL, '42964', 'Argentina');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (40, 'KIW020', 3, '2023-10-04', '2023-10-12', '2023-10-09', 1, 204.84, 'Harbor Wholesalers', '942 Oak St', 'Barcelona', NULL, '35806', 'Spain');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (41, 'GRA016', 7, '2024-07-08', '2024-07-16', '2024-07-09', 2, 254.36, 'Inverness Foods', '189 Oak St', 'Helsinki', NULL, '20800', 'Finland');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (42, 'BLU001', 4, '2024-06-16', '2024-07-02', '2024-06-19', 2, 159.55, 'Riviera Distributors', '701 Elm St', 'Cologne', NULL, '30471', 'Germany');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (43, 'ALF004', 4, '2024-06-24', '2024-07-04', '2024-06-25', 1, 185.32, 'Sequoia Gourmet', '474 Queen St', 'Rome', NULL, '42281', 'Italy');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (44, 'PAC010', 7, '2025-05-11', '2025-05-20', '2025-05-24', 2, 415.81, 'Quartz Trading', '368 Queen St', 'Amsterdam', NULL, '76182', 'Netherlands');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (45, 'PAC002', 9, '2025-10-29', '2025-11-04', '2025-11-01', 1, 481.50, 'Timber Provisioners', '668 Queen St', 'Monterrey', NULL, '63045', 'Mexico');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (46, 'VAL036', 9, '2024-12-30', '2025-01-18', '2024-12-31', 1, 440.22, 'Umbria Trading', '240 Queen St', 'Antwerp', NULL, '88355', 'Belgium');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (47, 'GRA016', 8, '2024-09-08', '2024-09-27', '2024-09-17', 2, 95.02, 'Inverness Foods', '189 Oak St', 'Helsinki', NULL, '20800', 'Finland');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (48, 'EVE027', 8, '2025-07-11', '2025-07-14', '2025-07-25', 3, 489.11, 'Harbor Distributors', '605 Pine Ave', 'Nice', NULL, '62404', 'France');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (49, 'INV039', 5, '2023-03-11', '2023-03-26', '2023-03-21', 3, 174.84, 'Willow Markets', '247 Queen St', 'Espoo', NULL, '67430', 'Finland');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (50, 'WIL033', 10, '2025-02-08', '2025-02-28', '2025-02-11', 1, 104.03, 'Pacific Wholesalers', '246 Pine Ave', 'Copenhagen', NULL, '43357', 'Denmark');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (51, 'WIL019', 3, '2024-10-20', '2024-10-23', '2024-10-27', 1, 160.23, 'Juniper Grocers', '379 Oak St', 'Aarhus', NULL, '80043', 'Denmark');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (52, 'JUN032', 9, '2024-07-30', '2024-08-11', '2024-08-13', 1, 402.24, 'Delta Wholesalers', '281 Pine Ave', 'Monterrey', NULL, '26678', 'Mexico');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (53, 'FRO015', 10, '2024-08-24', '2024-09-06', '2024-08-26', 1, 188.69, 'Lakeside Imports', '764 Maple Rd', 'Hamburg', NULL, '25330', 'Germany');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (54, 'PAC002', 4, '2023-08-31', '2023-09-18', '2023-09-11', 2, 22.59, 'Timber Provisioners', '668 Queen St', 'Monterrey', NULL, '63045', 'Mexico');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (55, 'INV039', 8, '2024-07-18', '2024-07-28', '2024-07-22', 2, 64.61, 'Willow Markets', '247 Queen St', 'Espoo', NULL, '67430', 'Finland');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (56, 'VAL036', 10, '2024-02-10', '2024-02-24', '2024-02-12', 3, 99.16, 'Umbria Trading', '240 Queen St', 'Antwerp', NULL, '88355', 'Belgium');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (57, 'GRA003', 4, '2024-12-11', '2024-12-30', '2024-12-23', 1, 90.85, 'Evergreen Grocers', '383 King St', 'Berlin', NULL, '65155', 'Germany');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (58, 'EVE027', 5, '2023-01-18', '2023-02-08', '2023-01-20', 1, 159.44, 'Harbor Distributors', '605 Pine Ave', 'Nice', NULL, '62404', 'France');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (59, 'WIL017', 7, '2025-06-16', '2025-06-19', '2025-06-22', 3, 199.03, 'Blue River Provisioners', '979 King St', 'Guadalajara', NULL, '61456', 'Mexico');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (60, 'WIL037', 6, '2023-09-27', '2023-10-14', '2023-10-10', 2, 197.01, 'Alfredo Wholesalers', '253 Elm St', 'Krakow', NULL, '44015', 'Poland');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (61, 'WIL012', 2, '2024-06-03', '2024-06-08', '2024-06-09', 1, 451.10, 'Lakeside Markets', '756 King St', 'Paris', NULL, '54715', 'France');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (62, 'ALF004', 1, '2024-04-12', '2024-04-20', '2024-04-22', 3, 463.89, 'Sequoia Gourmet', '474 Queen St', 'Rome', NULL, '42281', 'Italy');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (63, 'MON007', 4, '2023-09-26', '2023-10-10', '2023-10-06', 2, 287.67, 'Evergreen Delicatessen', '791 Maple Rd', 'Rosario', NULL, '78902', 'Argentina');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (64, 'KIW020', 9, '2025-12-11', '2025-12-30', '2025-12-19', 3, 24.52, 'Harbor Wholesalers', '942 Oak St', 'Barcelona', NULL, '35806', 'Spain');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (65, 'WIL019', 5, '2024-03-08', '2024-03-11', '2024-03-19', 1, 272.51, 'Juniper Grocers', '379 Oak St', 'Aarhus', NULL, '80043', 'Denmark');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (66, 'WIL023', 2, '2023-06-15', '2023-06-20', '2023-06-24', 1, 26.48, 'Natura Foods', '387 Maple Rd', 'Milan', NULL, '92925', 'Italy');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (67, 'WIL033', 10, '2024-07-30', '2024-08-18', '2024-07-31', 1, 145.56, 'Pacific Wholesalers', '246 Pine Ave', 'Copenhagen', NULL, '43357', 'Denmark');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (68, 'HAR022', 9, '2024-04-30', '2024-05-11', '2024-05-10', 1, 281.36, 'Blue River Grocers', '703 King St', 'Helsinki', NULL, '45744', 'Finland');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (69, 'GRA014', 10, '2024-07-28', '2024-08-13', '2024-08-01', 1, 88.64, 'Blue River Foods', '624 Maple Rd', 'Munich', NULL, '77556', 'Germany');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (70, 'CIT018', 7, '2024-10-19', '2024-10-23', '2024-10-25', 2, 262.18, 'Kiwi Gourmet', '465 Maple Rd', 'Gothenburg', NULL, '75547', 'Sweden');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (71, 'GRA003', 4, '2024-09-11', '2024-09-18', '2024-09-22', 2, 348.51, 'Evergreen Grocers', '383 King St', 'Berlin', NULL, '65155', 'Germany');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (72, 'NAT024', 6, '2024-01-15', '2024-01-19', '2024-01-17', 3, 338.13, 'Evergreen Grocers', '637 Oak St', 'Valencia', NULL, '48889', 'Spain');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (73, 'VAL038', 3, '2023-10-30', '2023-11-10', '2023-11-03', 3, 352.46, 'Umbria Grocers', '187 Queen St', 'Lisbon', NULL, '46242', 'Portugal');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (74, 'GRA016', 8, '2023-08-07', '2023-08-27', '2023-08-20', 3, 440.10, 'Inverness Foods', '189 Oak St', 'Helsinki', NULL, '20800', 'Finland');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (75, 'FRO015', 6, '2024-10-06', '2024-10-20', '2024-10-20', 3, 215.07, 'Lakeside Imports', '764 Maple Rd', 'Hamburg', NULL, '25330', 'Germany');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (76, 'WIL023', 8, '2024-09-27', '2024-10-01', '2024-10-07', 3, 324.09, 'Natura Foods', '387 Maple Rd', 'Milan', NULL, '92925', 'Italy');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (77, 'TIM025', 9, '2025-10-14', '2025-11-03', '1900-01-05', 2, 478.81, 'Oakridge Trading', '647 Queen St', 'Copenhagen', NULL, '31138', 'Denmark');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (78, 'JUN032', 2, '2023-07-15', '2023-07-27', '2023-07-17', 1, 92.86, 'Delta Wholesalers', '281 Pine Ave', 'Monterrey', NULL, '26678', 'Mexico');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (79, 'JUN032', 6, '2025-10-22', '2025-11-05', '2025-11-03', 1, 317.21, 'Delta Wholesalers', '281 Pine Ave', 'Monterrey', NULL, '26678', 'Mexico');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (80, 'GRA014', 6, '2025-06-07', '2025-06-23', '2025-06-09', 3, 328.62, 'Blue River Foods', '624 Maple Rd', 'Munich', NULL, '77556', 'Germany');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (81, 'ALF004', 8, '2022-12-22', '2023-01-10', '2022-12-26', 1, 495.57, 'Sequoia Gourmet', '474 Queen St', 'Rome', NULL, '42281', 'Italy');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (82, 'UMB034', 3, '2023-01-02', '2023-01-06', '2023-01-13', 3, 7.09, 'Willow Markets', '406 Oak St', 'Paris', NULL, '33381', 'France');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (83, 'VAL036', 3, '2022-08-31', '2022-09-10', '2022-09-06', 1, 270.98, 'Umbria Trading', '240 Queen St', 'Antwerp', NULL, '88355', 'Belgium');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (84, 'GRA016', 8, '2024-02-19', '2024-03-05', '2024-02-22', 2, 28.59, 'Inverness Foods', '189 Oak St', 'Helsinki', NULL, '20800', 'Finland');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (85, 'ZEN028', 4, '2024-11-28', '2024-12-04', '2024-12-12', 2, 307.49, 'Timber Grocers', '244 Pine Ave', 'Guadalajara', NULL, '98083', 'Mexico');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (86, 'JUN005', 9, '2022-05-17', '2022-05-20', '2022-05-26', 3, 309.13, 'Oakridge Markets', '863 King St', 'New York', NULL, '83750', 'USA');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (87, 'WIL023', 3, '2024-06-18', '2024-07-07', '2024-06-25', 2, 31.89, 'Natura Foods', '387 Maple Rd', 'Milan', NULL, '92925', 'Italy');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (88, 'FRO015', 2, '2025-12-06', '2025-12-09', '2025-12-20', 2, 385.76, 'Lakeside Imports', '764 Maple Rd', 'Hamburg', NULL, '25330', 'Germany');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (89, 'GRA013', 4, '2024-11-25', '2024-11-30', '2024-11-30', 3, 32.01, 'Valley Wholesalers', '366 Queen St', 'Sevilla', NULL, '26388', 'Spain');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (90, 'UMB030', 9, '2024-07-29', '2024-08-16', '2024-08-03', 1, 70.67, 'Harbor Gourmet', '819 Pine Ave', 'Rosario', NULL, '42964', 'Argentina');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (91, 'JUN032', 4, '2022-08-15', '2022-08-31', '2022-08-21', 3, 105.40, 'Delta Wholesalers', '281 Pine Ave', 'Monterrey', NULL, '26678', 'Mexico');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (92, 'OAK021', 6, '2022-09-30', '2022-10-14', '2022-10-02', 3, 35.48, 'Inverness Provisioners', '676 Maple Rd', 'Porto', NULL, '71077', 'Portugal');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (93, 'TIM025', 2, '2024-08-13', '2024-09-01', '2024-08-18', 3, 189.25, 'Oakridge Trading', '647 Queen St', 'Copenhagen', NULL, '31138', 'Denmark');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (94, 'JUN032', 10, '2022-06-04', '2022-06-24', '2022-06-10', 1, 96.20, 'Delta Wholesalers', '281 Pine Ave', 'Monterrey', NULL, '26678', 'Mexico');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (95, 'EVE027', 7, '2024-07-11', '2024-07-30', '2024-07-16', 2, 383.85, 'Harbor Distributors', '605 Pine Ave', 'Nice', NULL, '62404', 'France');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (96, 'NAT024', 9, '2024-09-17', '2024-09-27', '2024-09-27', 2, 171.35, 'Evergreen Grocers', '637 Oak St', 'Valencia', NULL, '48889', 'Spain');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (97, 'TIM025', 2, '2023-07-19', '2023-08-01', '2023-07-23', 1, 385.86, 'Oakridge Trading', '647 Queen St', 'Copenhagen', NULL, '31138', 'Denmark');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (98, 'GRA014', 9, '2023-11-30', '2023-12-21', '2023-12-14', 3, 464.67, 'Blue River Foods', '624 Maple Rd', 'Munich', NULL, '77556', 'Germany');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (99, 'ZEN028', 1, '2024-09-05', '2024-09-13', '2024-09-13', 2, 35.70, 'Timber Grocers', '244 Pine Ave', 'Guadalajara', NULL, '98083', 'Mexico');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (100, 'HAR029', 1, '2023-09-22', '2023-09-27', '2023-09-29', 3, 72.34, 'Pacific Foods', '727 Elm St', 'Milan', NULL, '75384', 'Italy');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (101, 'WIL012', 5, '2022-10-02', '2022-10-08', '2022-10-14', 1, 455.53, 'Lakeside Markets', '756 King St', 'Paris', NULL, '54715', 'France');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (102, 'JUN005', 6, '2023-11-08', '2023-11-27', '2023-11-12', 3, 309.09, 'Oakridge Markets', '863 King St', 'New York', NULL, '83750', 'USA');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (103, 'JUN032', 5, '2023-03-11', '2023-03-31', '2023-03-13', 2, 423.94, 'Delta Wholesalers', '281 Pine Ave', 'Monterrey', NULL, '26678', 'Mexico');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (104, 'LAK009', 7, '2023-07-10', '2023-07-31', '2023-07-24', 3, 29.08, 'Blue River Grocers', '711 Queen St', 'Amsterdam', NULL, '62351', 'Netherlands');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (105, 'KIW008', 4, '2024-08-08', '2024-08-12', '2024-08-22', 1, 68.65, 'Timber Provisioners', '355 Queen St', 'Porto', NULL, '73031', 'Portugal');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (106, 'INV040', 2, '2023-10-17', '2023-11-02', '2023-10-19', 2, 31.75, 'Oakridge Delicatessen', '66 Oak St', 'Naples', NULL, '29429', 'Italy');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (107, 'VAL036', 4, '2022-12-20', '2023-01-02', '2022-12-31', 3, 139.56, 'Umbria Trading', '240 Queen St', 'Antwerp', NULL, '88355', 'Belgium');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (108, 'NAT024', 6, '2023-11-25', '2023-12-11', '2023-12-05', 2, 137.40, 'Evergreen Grocers', '637 Oak St', 'Valencia', NULL, '48889', 'Spain');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (109, 'JUN005', 1, '2024-05-17', '2024-05-29', '2024-05-18', 1, 336.02, 'Oakridge Markets', '863 King St', 'New York', NULL, '83750', 'USA');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (110, 'WIL017', 7, '2022-11-22', '2022-12-05', '2022-11-28', 2, 70.31, 'Blue River Provisioners', '979 King St', 'Guadalajara', NULL, '61456', 'Mexico');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (111, 'LAK009', 3, '2023-11-27', '2023-12-09', '2023-12-01', 2, 227.60, 'Blue River Grocers', '711 Queen St', 'Amsterdam', NULL, '62351', 'Netherlands');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (112, 'WIL017', 9, '2024-11-23', '2024-12-07', '2024-11-28', 2, 376.97, 'Blue River Provisioners', '979 King St', 'Guadalajara', NULL, '61456', 'Mexico');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (113, 'UMB034', 4, '2022-04-17', '2022-05-01', '2022-04-28', 1, 91.52, 'Willow Markets', '406 Oak St', 'Paris', NULL, '33381', 'France');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (114, 'UMB030', 1, '2022-11-01', '2022-11-04', '2022-11-03', 1, 106.88, 'Harbor Gourmet', '819 Pine Ave', 'Rosario', NULL, '42964', 'Argentina');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (115, 'UMB030', 3, '2022-07-13', '2022-07-23', '2022-07-22', 3, 25.20, 'Harbor Gourmet', '819 Pine Ave', 'Rosario', NULL, '42964', 'Argentina');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (116, 'INV039', 9, '2022-09-23', '2022-10-01', '2022-10-04', 1, 200.05, 'Willow Markets', '247 Queen St', 'Espoo', NULL, '67430', 'Finland');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (117, 'VAL038', 4, '2023-02-08', '2023-02-26', '2023-02-11', 1, 447.65, 'Umbria Grocers', '187 Queen St', 'Lisbon', NULL, '46242', 'Portugal');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (118, 'GRA031', 6, '2023-05-08', '2023-05-13', '2023-05-19', 3, 378.67, 'Alfredo Foods', '509 Elm St', 'Barcelona', NULL, '34315', 'Spain');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (119, 'EVE027', 6, '2023-11-19', '2023-11-23', '2023-11-20', 3, 13.76, 'Harbor Distributors', '605 Pine Ave', 'Nice', NULL, '62404', 'France');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (120, 'WIL033', 5, '2024-09-14', '2024-09-25', '2024-09-15', 2, 346.57, 'Pacific Wholesalers', '246 Pine Ave', 'Copenhagen', NULL, '43357', 'Denmark');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (121, 'OAK035', 6, '2024-02-21', '2024-02-24', '2024-02-27', 2, 124.07, 'Evergreen Delicatessen', '390 Maple Rd', 'Curitiba', NULL, '31100', 'Brazil');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (122, 'WIL017', 9, '2024-01-22', '2024-01-29', '2024-01-23', 2, 356.51, 'Blue River Provisioners', '979 King St', 'Guadalajara', NULL, '61456', 'Mexico');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (123, 'WIL012', 8, '2022-01-19', '2022-02-06', '2022-01-31', 3, 230.72, 'Lakeside Markets', '756 King St', 'Paris', NULL, '54715', 'France');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (124, 'WIL033', 3, '2024-05-11', '2024-05-26', '2024-05-21', 3, 186.21, 'Pacific Wholesalers', '246 Pine Ave', 'Copenhagen', NULL, '43357', 'Denmark');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (125, 'INV040', 8, '2024-12-28', '2025-01-11', '2025-01-10', 2, 189.51, 'Oakridge Delicatessen', '66 Oak St', 'Naples', NULL, '29429', 'Italy');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (126, 'INV040', 5, '2024-12-16', '2024-12-29', '2024-12-25', 2, 263.51, 'Oakridge Delicatessen', '66 Oak St', 'Naples', NULL, '29429', 'Italy');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (127, 'TIM025', 4, '2022-11-21', '2022-11-24', '2022-12-03', 1, 466.63, 'Oakridge Trading', '647 Queen St', 'Copenhagen', NULL, '31138', 'Denmark');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (128, 'OAK021', 2, '2024-09-03', '2024-09-14', '2024-09-17', 1, 152.79, 'Inverness Provisioners', '676 Maple Rd', 'Porto', NULL, '71077', 'Portugal');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (129, 'WIL037', 2, '2023-06-20', '2023-06-28', '2023-07-03', 3, 143.44, 'Alfredo Wholesalers', '253 Elm St', 'Krakow', NULL, '44015', 'Poland');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (130, 'WIL023', 1, '2024-08-31', '2024-09-11', '2024-09-02', 3, 381.06, 'Natura Foods', '387 Maple Rd', 'Milan', NULL, '92925', 'Italy');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (131, 'WIL023', 3, '2024-04-17', '2024-04-21', '2024-05-01', 1, 371.53, 'Natura Foods', '387 Maple Rd', 'Milan', NULL, '92925', 'Italy');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (132, 'INV040', 7, '2022-06-25', '2022-07-14', '2022-07-05', 2, 85.49, 'Oakridge Delicatessen', '66 Oak St', 'Naples', NULL, '29429', 'Italy');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (133, 'LAK009', 10, '2023-02-20', '2023-03-03', '2023-02-28', 1, 348.77, 'Blue River Grocers', '711 Queen St', 'Amsterdam', NULL, '62351', 'Netherlands');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (134, 'PAC002', 1, '2024-08-26', '2024-09-08', '2024-09-03', 3, 59.85, 'Timber Provisioners', '668 Queen St', 'Monterrey', NULL, '63045', 'Mexico');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (135, 'HAR029', 10, '2023-03-16', '2023-03-29', '2023-03-20', 2, 39.72, 'Pacific Foods', '727 Elm St', 'Milan', NULL, '75384', 'Italy');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (136, 'WIL019', 10, '2024-06-08', '2024-06-24', '2024-06-20', 1, 135.59, 'Juniper Grocers', '379 Oak St', 'Aarhus', NULL, '80043', 'Denmark');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (137, 'WIL012', 2, '2024-02-01', '2024-02-20', '2024-02-06', 2, 302.74, 'Lakeside Markets', '756 King St', 'Paris', NULL, '54715', 'France');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (138, 'WIL019', 4, '2023-10-13', '2023-10-18', '2023-10-16', 2, 350.92, 'Juniper Grocers', '379 Oak St', 'Aarhus', NULL, '80043', 'Denmark');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (139, 'KIW020', 3, '2022-04-25', '2022-05-16', '2022-05-02', 1, 247.39, 'Harbor Wholesalers', '942 Oak St', 'Barcelona', NULL, '35806', 'Spain');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (140, 'GRA016', 8, '2024-02-07', '2024-02-12', '2024-02-09', 1, 425.62, 'Inverness Foods', '189 Oak St', 'Helsinki', NULL, '20800', 'Finland');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (141, 'WIL019', 6, '2024-04-05', '2024-04-10', '2024-04-14', 1, 193.77, 'Juniper Grocers', '379 Oak St', 'Aarhus', NULL, '80043', 'Denmark');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (142, 'UMB030', 8, '2024-10-08', '2024-10-18', '2024-10-15', 3, 184.85, 'Harbor Gourmet', '819 Pine Ave', 'Rosario', NULL, '42964', 'Argentina');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (143, 'GRA031', 2, '2024-03-16', '2024-04-03', '2024-03-21', 1, 67.15, 'Alfredo Foods', '509 Elm St', 'Barcelona', NULL, '34315', 'Spain');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (144, 'HAR029', 9, '2024-08-17', '2024-09-05', '2024-08-25', 2, 446.46, 'Pacific Foods', '727 Elm St', 'Milan', NULL, '75384', 'Italy');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (145, 'UMB030', 9, '2024-11-18', '2024-11-30', '2024-11-26', 3, 59.40, 'Harbor Gourmet', '819 Pine Ave', 'Rosario', NULL, '42964', 'Argentina');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (146, 'TIM025', 2, '2023-06-18', '2023-06-22', '2023-06-19', 1, 339.24, 'Oakridge Trading', '647 Queen St', 'Copenhagen', NULL, '31138', 'Denmark');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (147, 'KIW008', 5, '2023-05-15', '2023-05-24', '2023-05-24', 1, 77.43, 'Timber Provisioners', '355 Queen St', 'Porto', NULL, '73031', 'Portugal');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (148, 'WIL033', 1, '2023-02-20', '2023-03-09', '2023-03-03', 1, 233.06, 'Pacific Wholesalers', '246 Pine Ave', 'Copenhagen', NULL, '43357', 'Denmark');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (149, 'KIW008', 2, '2024-01-27', '2024-02-13', '2024-01-30', 1, 42.41, 'Timber Provisioners', '355 Queen St', 'Porto', NULL, '73031', 'Portugal');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (150, 'GRA003', 6, '2022-12-15', '2022-12-18', '2022-12-20', 1, 100.17, 'Evergreen Grocers', '383 King St', 'Berlin', NULL, '65155', 'Germany');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (151, 'JUN005', 5, '2024-10-15', '2024-10-20', '2024-10-17', 1, 336.27, 'Oakridge Markets', '863 King St', 'New York', NULL, '83750', 'USA');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (152, 'HAR022', 7, '2024-08-06', '2024-08-22', '2024-08-10', 1, 151.47, 'Blue River Grocers', '703 King St', 'Helsinki', NULL, '45744', 'Finland');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (153, 'GRA016', 10, '2023-04-10', '2023-04-22', '2023-04-12', 1, 319.76, 'Inverness Foods', '189 Oak St', 'Helsinki', NULL, '20800', 'Finland');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (154, 'GRA003', 7, '2024-02-07', '2024-02-23', '2024-02-21', 1, 220.27, 'Evergreen Grocers', '383 King St', 'Berlin', NULL, '65155', 'Germany');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (155, 'NAT024', 7, '2023-11-26', '2023-12-17', '2023-11-30', 2, 96.48, 'Evergreen Grocers', '637 Oak St', 'Valencia', NULL, '48889', 'Spain');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (156, 'WIL017', 7, '2023-10-05', '2023-10-18', '2023-10-06', 2, 432.32, 'Blue River Provisioners', '979 King St', 'Guadalajara', NULL, '61456', 'Mexico');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (157, 'VAL038', 5, '2023-06-13', '2023-06-28', '2023-06-26', 3, 458.32, 'Umbria Grocers', '187 Queen St', 'Lisbon', NULL, '46242', 'Portugal');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (158, 'GRA016', 2, '2024-03-05', '2024-03-09', '2024-03-08', 3, 127.99, 'Inverness Foods', '189 Oak St', 'Helsinki', NULL, '20800', 'Finland');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (159, 'GRA031', 6, '2023-04-11', '2023-04-29', '2023-04-17', 2, 250.86, 'Alfredo Foods', '509 Elm St', 'Barcelona', NULL, '34315', 'Spain');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (160, 'FRO015', 8, '2023-11-21', '2023-12-09', '2023-12-04', 3, 376.98, 'Lakeside Imports', '764 Maple Rd', 'Hamburg', NULL, '25330', 'Germany');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (161, 'MON007', 5, '2022-09-04', '2022-09-25', '2022-09-18', 1, 265.37, 'Evergreen Delicatessen', '791 Maple Rd', 'Rosario', NULL, '78902', 'Argentina');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (162, 'GRA016', 1, '2023-01-04', '2023-01-14', '2023-01-08', 3, 213.77, 'Inverness Foods', '189 Oak St', 'Helsinki', NULL, '20800', 'Finland');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (163, 'GRA031', 1, '2024-07-11', '2024-07-24', '2024-07-14', 3, 362.86, 'Alfredo Foods', '509 Elm St', 'Barcelona', NULL, '34315', 'Spain');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (164, 'OAK035', 1, '2023-11-03', '2023-11-17', '2023-11-07', 2, 353.29, 'Evergreen Delicatessen', '390 Maple Rd', 'Curitiba', NULL, '31100', 'Brazil');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (165, 'EVE027', 5, '2023-07-19', '2023-08-02', '2023-07-23', 2, 27.13, 'Harbor Distributors', '605 Pine Ave', 'Nice', NULL, '62404', 'France');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (166, 'CIT018', 10, '2022-10-21', '2022-10-28', '2022-10-26', 1, 59.60, 'Kiwi Gourmet', '465 Maple Rd', 'Gothenburg', NULL, '75547', 'Sweden');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (167, 'GRA031', 9, '2023-10-04', '2023-10-12', '2023-10-15', 1, 283.78, 'Alfredo Foods', '509 Elm St', 'Barcelona', NULL, '34315', 'Spain');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (168, 'FRO015', 8, '2022-01-29', '2022-02-19', '2022-02-09', 1, 476.54, 'Lakeside Imports', '764 Maple Rd', 'Hamburg', NULL, '25330', 'Germany');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (169, 'GRA014', 10, '2024-05-22', '2024-06-08', '2024-05-28', 1, 81.32, 'Blue River Foods', '624 Maple Rd', 'Munich', NULL, '77556', 'Germany');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (170, 'JUN005', 5, '2022-09-26', '2022-10-16', '2022-10-08', 3, 489.44, 'Oakridge Markets', '863 King St', 'New York', NULL, '83750', 'USA');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (171, 'VAL036', 6, '2024-04-22', '2024-05-02', '2024-04-29', 3, 380.93, 'Umbria Trading', '240 Queen St', 'Antwerp', NULL, '88355', 'Belgium');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (172, 'GRA016', 5, '2022-07-31', '2022-08-03', '2022-08-06', 3, 477.36, 'Inverness Foods', '189 Oak St', 'Helsinki', NULL, '20800', 'Finland');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (173, 'ALF004', 8, '2023-06-02', '2023-06-05', '2023-06-14', 1, 313.44, 'Sequoia Gourmet', '474 Queen St', 'Rome', NULL, '42281', 'Italy');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (174, 'WIL012', 7, '2022-11-26', '2022-12-11', '2022-12-01', 3, 96.86, 'Lakeside Markets', '756 King St', 'Paris', NULL, '54715', 'France');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (175, 'OAK035', 6, '2022-05-02', '2022-05-15', '2022-05-14', 3, 145.69, 'Evergreen Delicatessen', '390 Maple Rd', 'Curitiba', NULL, '31100', 'Brazil');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (176, 'BLU001', 3, '2024-01-30', '2024-02-02', '2024-02-13', 2, 397.49, 'Riviera Distributors', '701 Elm St', 'Cologne', NULL, '30471', 'Germany');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (177, 'WIL019', 3, '2022-05-08', '2022-05-23', '2022-05-14', 1, 298.87, 'Juniper Grocers', '379 Oak St', 'Aarhus', NULL, '80043', 'Denmark');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (178, 'GRA014', 10, '2024-11-24', '2024-12-09', '2024-12-06', 3, 413.28, 'Blue River Foods', '624 Maple Rd', 'Munich', NULL, '77556', 'Germany');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (179, 'GRA003', 10, '2023-11-19', '2023-11-23', '2023-11-26', 1, 484.89, 'Evergreen Grocers', '383 King St', 'Berlin', NULL, '65155', 'Germany');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (180, 'JUN032', 1, '2023-03-28', '2023-04-12', '2023-04-09', 3, 279.39, 'Delta Wholesalers', '281 Pine Ave', 'Monterrey', NULL, '26678', 'Mexico');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (181, 'MON007', 5, '2024-06-29', '2024-07-10', '2024-07-12', 1, 393.47, 'Evergreen Delicatessen', '791 Maple Rd', 'Rosario', NULL, '78902', 'Argentina');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (182, 'WIL017', 6, '2023-07-16', '2023-07-24', '2023-07-29', 3, 133.39, 'Blue River Provisioners', '979 King St', 'Guadalajara', NULL, '61456', 'Mexico');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (183, 'PAC002', 8, '2022-07-12', '2022-07-21', '2022-07-20', 1, 18.63, 'Timber Provisioners', '668 Queen St', 'Monterrey', NULL, '63045', 'Mexico');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (184, 'KIW020', 9, '2023-11-13', '2023-11-29', '2023-11-17', 1, 282.08, 'Harbor Wholesalers', '942 Oak St', 'Barcelona', NULL, '35806', 'Spain');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (185, 'LAK009', 4, '2024-10-01', '2024-10-09', '2024-10-02', 3, 440.73, 'Blue River Grocers', '711 Queen St', 'Amsterdam', NULL, '62351', 'Netherlands');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (186, 'LAK009', 4, '2023-04-07', '2023-04-14', '2023-04-17', 2, 121.34, 'Blue River Grocers', '711 Queen St', 'Amsterdam', NULL, '62351', 'Netherlands');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (187, 'INV040', 2, '2024-11-13', '2024-11-25', '2024-11-14', 1, 111.93, 'Oakridge Delicatessen', '66 Oak St', 'Naples', NULL, '29429', 'Italy');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (188, 'GRA031', 2, '2023-08-22', '2023-08-25', '2023-09-04', 1, 136.42, 'Alfredo Foods', '509 Elm St', 'Barcelona', NULL, '34315', 'Spain');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (189, 'PAC011', 4, '2024-07-07', '2024-07-23', '2024-07-15', 1, 274.11, 'Monarch Markets', '895 Maple Rd', 'Monterrey', NULL, '21567', 'Mexico');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (190, 'MON007', 1, '2024-09-14', '2024-09-28', '2024-09-27', 3, 195.21, 'Evergreen Delicatessen', '791 Maple Rd', 'Rosario', NULL, '78902', 'Argentina');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (191, 'GRA003', 5, '2024-11-14', '2024-12-03', '2024-11-26', 1, 498.10, 'Evergreen Grocers', '383 King St', 'Berlin', NULL, '65155', 'Germany');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (192, 'EVE027', 3, '2023-04-24', '2023-05-04', '2023-05-04', 1, 63.87, 'Harbor Distributors', '605 Pine Ave', 'Nice', NULL, '62404', 'France');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (193, 'PAC010', 7, '2023-08-25', '2023-09-08', '2023-08-27', 1, 288.30, 'Quartz Trading', '368 Queen St', 'Amsterdam', NULL, '76182', 'Netherlands');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (194, 'UMB030', 2, '2023-03-13', '2023-03-25', '2023-03-19', 1, 69.82, 'Harbor Gourmet', '819 Pine Ave', 'Rosario', NULL, '42964', 'Argentina');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (195, 'KIW008', 10, '2023-08-06', '2023-08-23', '2023-08-18', 1, 217.75, 'Timber Provisioners', '355 Queen St', 'Porto', NULL, '73031', 'Portugal');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (196, 'PAC002', 2, '2024-06-25', '2024-07-02', '2024-07-07', 1, 274.35, 'Timber Provisioners', '668 Queen St', 'Monterrey', NULL, '63045', 'Mexico');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (197, 'GRA031', 2, '2024-08-07', '2024-08-10', '2024-08-15', 1, 469.41, 'Alfredo Foods', '509 Elm St', 'Barcelona', NULL, '34315', 'Spain');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (198, 'KIW008', 7, '2022-04-28', '2022-05-18', '2022-05-10', 2, 38.79, 'Timber Provisioners', '355 Queen St', 'Porto', NULL, '73031', 'Portugal');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (199, 'WIL033', 3, '2022-11-02', '2022-11-23', '2022-11-14', 2, 70.19, 'Pacific Wholesalers', '246 Pine Ave', 'Copenhagen', NULL, '43357', 'Denmark');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (200, 'UMB034', 10, '2024-04-16', '2024-04-25', '2024-04-19', 1, 163.56, 'Willow Markets', '406 Oak St', 'Paris', NULL, '33381', 'France');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (201, 'TIM025', 6, '2026-01-04', '2026-01-18', '2026-01-10', 1, 25.98, 'Oakridge Trading', '647 Queen St', 'Copenhagen', NULL, '31138', 'Denmark');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (202, 'KIW020', 1, '2026-01-16', '2026-01-30', '2026-01-23', 1, 66.19, 'Harbor Wholesalers', '942 Oak St', 'Barcelona', NULL, '35806', 'Spain');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (203, 'PAC002', 10, '2026-01-19', '2026-02-02', '2026-01-21', 3, 108.66, 'Timber Provisioners', '668 Queen St', 'Monterrey', NULL, '63045', 'Mexico');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (204, 'KIW020', 2, '2026-01-31', '2026-02-14', '2026-02-08', 2, 17.29, 'Harbor Wholesalers', '942 Oak St', 'Barcelona', NULL, '35806', 'Spain');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (205, 'KIW020', 9, '2026-02-01', '2026-02-15', '2026-02-04', 1, 62.88, 'Harbor Wholesalers', '942 Oak St', 'Barcelona', NULL, '35806', 'Spain');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (206, 'ALF004', 10, '2026-02-05', '2026-02-19', '2026-02-10', 2, 54.81, 'Sequoia Gourmet', '474 Queen St', 'Rome', NULL, '42281', 'Italy');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (207, 'ALF004', 1, '2026-02-10', '2026-02-24', '2026-02-13', 1, 111.76, 'Sequoia Gourmet', '474 Queen St', 'Rome', NULL, '42281', 'Italy');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (208, 'FRO015', 10, '2026-02-16', '2026-03-02', '2026-02-20', 1, 116.34, 'Lakeside Imports', '764 Maple Rd', 'Hamburg', NULL, '25330', 'Germany');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (209, 'JUN005', 1, '2026-02-21', '2026-03-07', '2026-02-27', 1, 73.22, 'Oakridge Markets', '863 King St', 'New York', NULL, '83750', 'USA');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (210, 'WIL023', 6, '2026-02-23', '2026-03-09', '2026-03-01', 2, 83.05, 'Natura Foods', '387 Maple Rd', 'Milan', NULL, '92925', 'Italy');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (211, 'CIT018', 6, '2026-03-02', '2026-03-16', '2026-03-07', 1, 102.34, 'Kiwi Gourmet', '465 Maple Rd', 'Gothenburg', NULL, '75547', 'Sweden');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (212, 'JUN032', 6, '2026-03-10', '2026-03-24', '2026-03-19', 1, 58.07, 'Delta Wholesalers', '281 Pine Ave', 'Monterrey', NULL, '26678', 'Mexico');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (213, 'EVE027', 9, '2026-03-12', '2026-03-26', '2026-03-14', 2, 15.71, 'Harbor Distributors', '605 Pine Ave', 'Nice', NULL, '62404', 'France');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (214, 'KIW020', 6, '2026-03-19', '2026-04-02', '2026-03-22', 2, 91.13, 'Harbor Wholesalers', '942 Oak St', 'Barcelona', NULL, '35806', 'Spain');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (215, 'CIT018', 3, '2026-03-20', '2026-04-03', '2026-03-23', 3, 94.81, 'Kiwi Gourmet', '465 Maple Rd', 'Gothenburg', NULL, '75547', 'Sweden');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (216, 'WIL017', 3, '2026-03-21', '2026-04-04', '2026-03-29', 3, 19.00, 'Blue River Provisioners', '979 King St', 'Guadalajara', NULL, '61456', 'Mexico');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (217, 'FRO015', 4, '2026-03-22', '2026-04-05', '2026-03-26', 2, 108.88, 'Lakeside Imports', '764 Maple Rd', 'Hamburg', NULL, '25330', 'Germany');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (218, 'ALF004', 8, '2026-04-05', '2026-04-19', '2026-04-07', 1, 87.93, 'Sequoia Gourmet', '474 Queen St', 'Rome', NULL, '42281', 'Italy');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (219, 'CIT018', 1, '2026-04-07', '2026-04-21', '2026-04-14', 1, 22.05, 'Kiwi Gourmet', '465 Maple Rd', 'Gothenburg', NULL, '75547', 'Sweden');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (220, 'ALF004', 1, '2026-04-17', '2026-05-01', '2026-04-23', 1, 57.19, 'Sequoia Gourmet', '474 Queen St', 'Rome', NULL, '42281', 'Italy');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (221, 'FRO015', 10, '2026-04-18', '2026-05-02', '2026-04-24', 3, 28.46, 'Lakeside Imports', '764 Maple Rd', 'Hamburg', NULL, '25330', 'Germany');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (222, 'KIW020', 3, '2026-04-21', '2026-05-05', '2026-04-25', 3, 69.20, 'Harbor Wholesalers', '942 Oak St', 'Barcelona', NULL, '35806', 'Spain');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (223, 'WIL017', 8, '2026-04-22', '2026-05-06', '2026-05-01', 2, 57.54, 'Blue River Provisioners', '979 King St', 'Guadalajara', NULL, '61456', 'Mexico');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (224, 'TIM025', 10, '2026-04-23', '2026-05-07', '2026-05-01', 2, 71.89, 'Oakridge Trading', '647 Queen St', 'Copenhagen', NULL, '31138', 'Denmark');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (225, 'FRO015', 7, '2026-05-03', '2026-05-17', '2026-05-07', 3, 98.67, 'Lakeside Imports', '764 Maple Rd', 'Hamburg', NULL, '25330', 'Germany');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (226, 'EVE027', 1, '2026-05-05', '2026-05-19', '2026-05-14', 1, 10.01, 'Harbor Distributors', '605 Pine Ave', 'Nice', NULL, '62404', 'France');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (227, 'PAC002', 9, '2026-05-07', '2026-05-21', '2026-05-16', 3, 98.21, 'Timber Provisioners', '668 Queen St', 'Monterrey', NULL, '63045', 'Mexico');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (228, 'JUN005', 1, '2026-05-09', '2026-05-23', '2026-05-13', 1, 68.70, 'Oakridge Markets', '863 King St', 'New York', NULL, '83750', 'USA');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (229, 'JUN032', 10, '2026-05-13', '2026-05-27', '2026-05-17', 2, 37.46, 'Delta Wholesalers', '281 Pine Ave', 'Monterrey', NULL, '26678', 'Mexico');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (230, 'JUN032', 3, '2026-05-17', '2026-05-31', '2026-05-26', 3, 116.32, 'Delta Wholesalers', '281 Pine Ave', 'Monterrey', NULL, '26678', 'Mexico');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (231, 'JUN032', 6, '2026-05-18', '2026-06-01', '2026-05-25', 1, 60.54, 'Delta Wholesalers', '281 Pine Ave', 'Monterrey', NULL, '26678', 'Mexico');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (232, 'TIM025', 1, '2026-05-19', '2026-06-02', '2026-05-26', 1, 24.96, 'Oakridge Trading', '647 Queen St', 'Copenhagen', NULL, '31138', 'Denmark');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (233, 'BLU006', 6, '2026-05-21', '2026-06-04', '2026-05-29', 1, 97.43, 'Lakeside Trading', '831 Pine Ave', 'São Paulo', NULL, '65230', 'Brazil');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (234, 'PAC002', 7, '2026-05-22', '2026-06-05', '2026-05-30', 1, 77.59, 'Timber Provisioners', '668 Queen St', 'Monterrey', NULL, '63045', 'Mexico');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (235, 'KIW020', 2, '2026-05-29', '2026-06-12', '2026-06-05', 2, 62.17, 'Harbor Wholesalers', '942 Oak St', 'Barcelona', NULL, '35806', 'Spain');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (236, 'UMB030', 4, '2026-06-02', '2026-06-16', '2026-06-08', 3, 57.94, 'Harbor Gourmet', '819 Pine Ave', 'Rosario', NULL, '42964', 'Argentina');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (237, 'UMB030', 1, '2026-06-04', '2026-06-18', '2026-06-08', 1, 111.45, 'Harbor Gourmet', '819 Pine Ave', 'Rosario', NULL, '42964', 'Argentina');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (238, 'WIL023', 9, '2026-06-05', '2026-06-19', '2026-06-14', 3, 68.33, 'Natura Foods', '387 Maple Rd', 'Milan', NULL, '92925', 'Italy');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (239, 'CIT018', 1, '2026-06-09', '2026-06-23', '2026-06-12', 1, 87.24, 'Kiwi Gourmet', '465 Maple Rd', 'Gothenburg', NULL, '75547', 'Sweden');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (240, 'WIL017', 9, '2026-06-10', '2026-06-24', '2026-06-14', 2, 89.26, 'Blue River Provisioners', '979 King St', 'Guadalajara', NULL, '61456', 'Mexico');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (241, 'WIL033', 5, '2026-06-14', '2026-06-28', '2026-06-16', 2, 87.81, 'Pacific Wholesalers', '246 Pine Ave', 'Copenhagen', NULL, '43357', 'Denmark');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (242, 'WIL033', 6, '2026-06-15', '2026-06-29', '2026-06-21', 1, 64.81, 'Pacific Wholesalers', '246 Pine Ave', 'Copenhagen', NULL, '43357', 'Denmark');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (243, 'UMB030', 6, '2026-06-20', '2026-07-04', '2026-06-25', 3, 115.97, 'Harbor Gourmet', '819 Pine Ave', 'Rosario', NULL, '42964', 'Argentina');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (244, 'PAC010', 10, '2026-06-22', '2026-07-06', '2026-06-28', 3, 117.55, 'Quartz Trading', '368 Queen St', 'Amsterdam', NULL, '76182', 'Netherlands');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (245, 'TIM025', 7, '2026-06-23', '2026-07-07', '2026-06-26', 1, 35.94, 'Oakridge Trading', '647 Queen St', 'Copenhagen', NULL, '31138', 'Denmark');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (246, 'JUN032', 3, '2026-06-25', '2026-07-09', '2026-07-02', 3, 105.00, 'Delta Wholesalers', '281 Pine Ave', 'Monterrey', NULL, '26678', 'Mexico');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (247, 'PAC002', 8, '2026-06-27', '2026-07-11', '2026-07-04', 2, 60.62, 'Timber Provisioners', '668 Queen St', 'Monterrey', NULL, '63045', 'Mexico');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (248, 'CIT018', 3, '2026-06-28', '2026-07-12', '2026-07-07', 3, 47.81, 'Kiwi Gourmet', '465 Maple Rd', 'Gothenburg', NULL, '75547', 'Sweden');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (249, 'WIL033', 5, '2026-06-29', '2026-07-13', '2026-07-07', 3, 118.62, 'Pacific Wholesalers', '246 Pine Ave', 'Copenhagen', NULL, '43357', 'Denmark');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (250, 'GRA014', 10, '2026-07-04', '2026-07-18', '2026-07-07', 3, 70.45, 'Blue River Foods', '624 Maple Rd', 'Munich', NULL, '77556', 'Germany');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (251, 'WIL017', 5, '2026-07-05', '2026-07-19', '2026-07-14', 3, 16.50, 'Blue River Provisioners', '979 King St', 'Guadalajara', NULL, '61456', 'Mexico');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (252, 'CIT018', 1, '2026-07-09', '2026-07-23', '2026-07-16', 1, 56.14, 'Kiwi Gourmet', '465 Maple Rd', 'Gothenburg', NULL, '75547', 'Sweden');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (253, 'PAC010', 1, '2026-07-10', '2026-07-24', '2026-07-12', 1, 57.38, 'Quartz Trading', '368 Queen St', 'Amsterdam', NULL, '76182', 'Netherlands');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (254, 'KIW020', 8, '2026-07-11', '2026-07-25', '2026-07-16', 3, 13.44, 'Harbor Wholesalers', '942 Oak St', 'Barcelona', NULL, '35806', 'Spain');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (255, 'UMB030', 2, '2026-07-12', '2026-07-26', '2026-07-21', 2, 49.17, 'Harbor Gourmet', '819 Pine Ave', 'Rosario', NULL, '42964', 'Argentina');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (256, 'WIL017', 1, '2026-07-15', '2026-07-29', '2026-07-20', 1, 47.36, 'Blue River Provisioners', '979 King St', 'Guadalajara', NULL, '61456', 'Mexico');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (257, 'GRA014', 5, '2026-07-19', '2026-08-02', '2026-07-27', 1, 103.28, 'Blue River Foods', '624 Maple Rd', 'Munich', NULL, '77556', 'Germany');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (258, 'EVE027', 6, '2026-07-20', '2026-08-03', NULL, 1, 26.26, 'Harbor Distributors', '605 Pine Ave', 'Nice', NULL, '62404', 'France');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (259, 'PAC010', 3, '2026-07-21', '2026-08-04', '2026-07-27', 3, 60.71, 'Quartz Trading', '368 Queen St', 'Amsterdam', NULL, '76182', 'Netherlands');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (260, 'CIT018', 10, '2026-07-22', '2026-08-05', NULL, 2, 29.02, 'Kiwi Gourmet', '465 Maple Rd', 'Gothenburg', NULL, '75547', 'Sweden');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (261, 'WIL033', 5, '2026-07-23', '2026-08-06', '2026-07-27', 2, 78.21, 'Pacific Wholesalers', '246 Pine Ave', 'Copenhagen', NULL, '43357', 'Denmark');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (262, 'UMB030', 2, '2026-07-24', '2026-08-07', '2026-07-31', 2, 71.38, 'Harbor Gourmet', '819 Pine Ave', 'Rosario', NULL, '42964', 'Argentina');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (263, 'WIL023', 4, '2026-07-25', '2026-08-08', '2026-08-02', 3, 95.08, 'Natura Foods', '387 Maple Rd', 'Milan', NULL, '92925', 'Italy');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (264, 'WIL023', 1, '2026-07-26', '2026-08-09', NULL, 1, 21.06, 'Natura Foods', '387 Maple Rd', 'Milan', NULL, '92925', 'Italy');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (265, 'PAC002', 7, '2026-07-29', '2026-08-12', NULL, 1, 40.45, 'Timber Provisioners', '668 Queen St', 'Monterrey', NULL, '63045', 'Mexico');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (266, 'WIL033', 6, '2026-08-01', '2026-08-15', NULL, 3, 119.84, 'Pacific Wholesalers', '246 Pine Ave', 'Copenhagen', NULL, '43357', 'Denmark');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (267, 'BLU006', 7, '2026-08-04', '2026-08-18', NULL, 1, 110.30, 'Lakeside Trading', '831 Pine Ave', 'São Paulo', NULL, '65230', 'Brazil');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (268, 'BLU006', 9, '2026-08-06', '2026-08-20', NULL, 1, 64.35, 'Lakeside Trading', '831 Pine Ave', 'São Paulo', NULL, '65230', 'Brazil');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (269, 'UMB030', 4, '2026-08-07', '2026-08-21', NULL, 1, 33.45, 'Harbor Gourmet', '819 Pine Ave', 'Rosario', NULL, '42964', 'Argentina');
INSERT INTO "public"."orders" ("order_id", "customer_id", "employee_id", "order_date", "required_date", "shipped_date", "ship_via", "freight", "ship_name", "ship_address", "ship_city", "ship_region", "ship_postal_code", "ship_country") VALUES (270, 'WIL033', 6, '2026-08-08', '2026-08-22', '2026-08-12', 3, 75.87, 'Pacific Wholesalers', '246 Pine Ave', 'Copenhagen', NULL, '43357', 'Denmark');


--
-- Data for Name: products; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO "public"."products" ("product_id", "product_name", "supplier_id", "category_id", "quantity_per_unit", "unit_price", "units_in_stock", "units_on_order", "reorder_level", "discontinued") VALUES (1, 'Ethiopian Arabica Coffee', 11, 1, '24 - 12 oz bottles', 66.82, 94, 14, 28, 0);
INSERT INTO "public"."products" ("product_id", "product_name", "supplier_id", "category_id", "quantity_per_unit", "unit_price", "units_in_stock", "units_on_order", "reorder_level", "discontinued") VALUES (2, 'Colombian Dark Roast', 3, 1, '48 - 6 oz jars', 111.79, 62, 13, 28, 0);
INSERT INTO "public"."products" ("product_id", "product_name", "supplier_id", "category_id", "quantity_per_unit", "unit_price", "units_in_stock", "units_on_order", "reorder_level", "discontinued") VALUES (3, 'Earl Grey Tea', 9, 1, '12 - 200 g jars', 8.03, 128, 5, 30, 0);
INSERT INTO "public"."products" ("product_id", "product_name", "supplier_id", "category_id", "quantity_per_unit", "unit_price", "units_in_stock", "units_on_order", "reorder_level", "discontinued") VALUES (4, 'Chamomile Tea', 17, 1, '20 - 1 kg packs', 91.70, 4, 12, 8, 0);
INSERT INTO "public"."products" ("product_id", "product_name", "supplier_id", "category_id", "quantity_per_unit", "unit_price", "units_in_stock", "units_on_order", "reorder_level", "discontinued") VALUES (5, 'Organic Apple Juice', 3, 1, '36 boxes', 12.80, 141, 34, 4, 0);
INSERT INTO "public"."products" ("product_id", "product_name", "supplier_id", "category_id", "quantity_per_unit", "unit_price", "units_in_stock", "units_on_order", "reorder_level", "discontinued") VALUES (6, 'Sparkling Orange Soda', 16, 1, '16 kg pack', 88.48, 198, 1, 8, 1);
INSERT INTO "public"."products" ("product_id", "product_name", "supplier_id", "category_id", "quantity_per_unit", "unit_price", "units_in_stock", "units_on_order", "reorder_level", "discontinued") VALUES (7, 'Craft Pilsner', 11, 1, '12 - 200 g jars', 110.00, 128, 8, 19, 0);
INSERT INTO "public"."products" ("product_id", "product_name", "supplier_id", "category_id", "quantity_per_unit", "unit_price", "units_in_stock", "units_on_order", "reorder_level", "discontinued") VALUES (8, 'Hefeweizen Beer', 20, 1, '16 kg pack', 43.18, 149, 7, 22, 0);
INSERT INTO "public"."products" ("product_id", "product_name", "supplier_id", "category_id", "quantity_per_unit", "unit_price", "units_in_stock", "units_on_order", "reorder_level", "discontinued") VALUES (9, 'Smoked Chipotle Sauce', 12, 2, '16 kg pack', 45.34, 171, 26, 10, 0);
INSERT INTO "public"."products" ("product_id", "product_name", "supplier_id", "category_id", "quantity_per_unit", "unit_price", "units_in_stock", "units_on_order", "reorder_level", "discontinued") VALUES (10, 'Wholegrain Mustard', 7, 2, '16 kg pack', 43.13, 192, 12, 26, 0);
INSERT INTO "public"."products" ("product_id", "product_name", "supplier_id", "category_id", "quantity_per_unit", "unit_price", "units_in_stock", "units_on_order", "reorder_level", "discontinued") VALUES (11, 'Balsamic Glaze', 13, 2, '10 boxes x 20 bags', 101.47, 96, 32, 8, 0);
INSERT INTO "public"."products" ("product_id", "product_name", "supplier_id", "category_id", "quantity_per_unit", "unit_price", "units_in_stock", "units_on_order", "reorder_level", "discontinued") VALUES (12, 'Pesto alla Genovese', 18, 2, '12 - 200 g jars', 46.12, 75, 7, 29, 0);
INSERT INTO "public"."products" ("product_id", "product_name", "supplier_id", "category_id", "quantity_per_unit", "unit_price", "units_in_stock", "units_on_order", "reorder_level", "discontinued") VALUES (13, 'Garlic Aioli', 17, 2, '36 boxes', 9.42, 97, 3, 18, 1);
INSERT INTO "public"."products" ("product_id", "product_name", "supplier_id", "category_id", "quantity_per_unit", "unit_price", "units_in_stock", "units_on_order", "reorder_level", "discontinued") VALUES (14, 'Harissa Paste', 10, 2, '24 - 12 oz bottles', 57.47, 195, 45, 10, 0);
INSERT INTO "public"."products" ("product_id", "product_name", "supplier_id", "category_id", "quantity_per_unit", "unit_price", "units_in_stock", "units_on_order", "reorder_level", "discontinued") VALUES (15, 'Soy Sauce Premium', 15, 2, '48 - 6 oz jars', 101.38, 144, 36, 11, 0);
INSERT INTO "public"."products" ("product_id", "product_name", "supplier_id", "category_id", "quantity_per_unit", "unit_price", "units_in_stock", "units_on_order", "reorder_level", "discontinued") VALUES (16, 'Sesame Teriyaki', 15, 2, '48 - 6 oz jars', 42.45, 12, 11, 3, 0);
INSERT INTO "public"."products" ("product_id", "product_name", "supplier_id", "category_id", "quantity_per_unit", "unit_price", "units_in_stock", "units_on_order", "reorder_level", "discontinued") VALUES (17, 'Belgian Dark Chocolate', 14, 3, '16 kg pack', 88.85, 122, 34, 1, 1);
INSERT INTO "public"."products" ("product_id", "product_name", "supplier_id", "category_id", "quantity_per_unit", "unit_price", "units_in_stock", "units_on_order", "reorder_level", "discontinued") VALUES (18, 'Almond Biscotti', 18, 3, '12 - 500 ml bottles', 41.12, 94, 14, 19, 0);
INSERT INTO "public"."products" ("product_id", "product_name", "supplier_id", "category_id", "quantity_per_unit", "unit_price", "units_in_stock", "units_on_order", "reorder_level", "discontinued") VALUES (19, 'Lemon Shortbread', 15, 3, '48 - 6 oz jars', 85.57, 3, 20, 23, 1);
INSERT INTO "public"."products" ("product_id", "product_name", "supplier_id", "category_id", "quantity_per_unit", "unit_price", "units_in_stock", "units_on_order", "reorder_level", "discontinued") VALUES (20, 'Hazelnut Pralines', 8, 3, '24 - 12 oz bottles', 104.98, 72, 10, 13, 0);
INSERT INTO "public"."products" ("product_id", "product_name", "supplier_id", "category_id", "quantity_per_unit", "unit_price", "units_in_stock", "units_on_order", "reorder_level", "discontinued") VALUES (21, 'Vanilla Caramels', 14, 3, '10 boxes x 20 bags', 74.03, 127, 43, 5, 0);
INSERT INTO "public"."products" ("product_id", "product_name", "supplier_id", "category_id", "quantity_per_unit", "unit_price", "units_in_stock", "units_on_order", "reorder_level", "discontinued") VALUES (22, 'Strawberry Marshmallows', 2, 3, '48 - 6 oz jars', 64.40, 195, 47, 29, 0);
INSERT INTO "public"."products" ("product_id", "product_name", "supplier_id", "category_id", "quantity_per_unit", "unit_price", "units_in_stock", "units_on_order", "reorder_level", "discontinued") VALUES (23, 'Panettone Mini', 10, 3, '16 kg pack', 104.28, 119, 14, 9, 0);
INSERT INTO "public"."products" ("product_id", "product_name", "supplier_id", "category_id", "quantity_per_unit", "unit_price", "units_in_stock", "units_on_order", "reorder_level", "discontinued") VALUES (24, 'Coconut Macaroons', 4, 3, '16 kg pack', 74.70, 142, 17, 25, 0);
INSERT INTO "public"."products" ("product_id", "product_name", "supplier_id", "category_id", "quantity_per_unit", "unit_price", "units_in_stock", "units_on_order", "reorder_level", "discontinued") VALUES (25, 'Aged Cheddar', 17, 4, '24 - 12 oz bottles', 77.35, 100, 26, 25, 1);
INSERT INTO "public"."products" ("product_id", "product_name", "supplier_id", "category_id", "quantity_per_unit", "unit_price", "units_in_stock", "units_on_order", "reorder_level", "discontinued") VALUES (26, 'Goat Cheese Log', 4, 4, '10 boxes x 20 bags', 69.69, 194, 41, 13, 0);
INSERT INTO "public"."products" ("product_id", "product_name", "supplier_id", "category_id", "quantity_per_unit", "unit_price", "units_in_stock", "units_on_order", "reorder_level", "discontinued") VALUES (27, 'Greek Yogurt', 5, 4, '16 kg pack', 18.74, 54, 15, 1, 0);
INSERT INTO "public"."products" ("product_id", "product_name", "supplier_id", "category_id", "quantity_per_unit", "unit_price", "units_in_stock", "units_on_order", "reorder_level", "discontinued") VALUES (28, 'Mascarpone', 7, 4, '24 - 12 oz bottles', 50.23, 6, 0, 13, 0);
INSERT INTO "public"."products" ("product_id", "product_name", "supplier_id", "category_id", "quantity_per_unit", "unit_price", "units_in_stock", "units_on_order", "reorder_level", "discontinued") VALUES (29, 'Parmigiano Reggiano', 18, 4, '10 boxes x 20 bags', 7.90, 63, 46, 28, 1);
INSERT INTO "public"."products" ("product_id", "product_name", "supplier_id", "category_id", "quantity_per_unit", "unit_price", "units_in_stock", "units_on_order", "reorder_level", "discontinued") VALUES (30, 'Feta Cheese', 10, 4, '12 - 500 ml bottles', 38.59, 72, 42, 20, 0);
INSERT INTO "public"."products" ("product_id", "product_name", "supplier_id", "category_id", "quantity_per_unit", "unit_price", "units_in_stock", "units_on_order", "reorder_level", "discontinued") VALUES (31, 'Salted Butter', 7, 4, '10 boxes x 20 bags', 90.59, 39, 29, 7, 1);
INSERT INTO "public"."products" ("product_id", "product_name", "supplier_id", "category_id", "quantity_per_unit", "unit_price", "units_in_stock", "units_on_order", "reorder_level", "discontinued") VALUES (32, 'Crème Fraîche', 8, 4, '12 - 200 g jars', 48.71, 48, 24, 2, 1);
INSERT INTO "public"."products" ("product_id", "product_name", "supplier_id", "category_id", "quantity_per_unit", "unit_price", "units_in_stock", "units_on_order", "reorder_level", "discontinued") VALUES (33, 'Artisan Sourdough Bread', 2, 5, '48 - 6 oz jars', 19.29, 187, 46, 29, 0);
INSERT INTO "public"."products" ("product_id", "product_name", "supplier_id", "category_id", "quantity_per_unit", "unit_price", "units_in_stock", "units_on_order", "reorder_level", "discontinued") VALUES (34, 'Organic Spaghetti', 5, 5, '24 - 12 oz bottles', 56.83, 90, 35, 19, 0);
INSERT INTO "public"."products" ("product_id", "product_name", "supplier_id", "category_id", "quantity_per_unit", "unit_price", "units_in_stock", "units_on_order", "reorder_level", "discontinued") VALUES (35, 'Quinoa Blend', 15, 5, '36 boxes', 36.78, 54, 24, 29, 0);
INSERT INTO "public"."products" ("product_id", "product_name", "supplier_id", "category_id", "quantity_per_unit", "unit_price", "units_in_stock", "units_on_order", "reorder_level", "discontinued") VALUES (36, 'Brown Rice', 4, 5, '24 - 12 oz bottles', 72.36, 83, 47, 2, 0);
INSERT INTO "public"."products" ("product_id", "product_name", "supplier_id", "category_id", "quantity_per_unit", "unit_price", "units_in_stock", "units_on_order", "reorder_level", "discontinued") VALUES (37, 'Wholegrain Crackers', 13, 5, '12 - 500 ml bottles', 52.00, 121, 8, 27, 0);
INSERT INTO "public"."products" ("product_id", "product_name", "supplier_id", "category_id", "quantity_per_unit", "unit_price", "units_in_stock", "units_on_order", "reorder_level", "discontinued") VALUES (38, 'Oatmeal Cereal', 6, 5, '24 - 12 oz bottles', 41.73, 25, 9, 7, 1);
INSERT INTO "public"."products" ("product_id", "product_name", "supplier_id", "category_id", "quantity_per_unit", "unit_price", "units_in_stock", "units_on_order", "reorder_level", "discontinued") VALUES (39, 'Couscous', 14, 5, '20 - 1 kg packs', 80.37, 15, 3, 4, 0);
INSERT INTO "public"."products" ("product_id", "product_name", "supplier_id", "category_id", "quantity_per_unit", "unit_price", "units_in_stock", "units_on_order", "reorder_level", "discontinued") VALUES (40, 'Rye Crispbread', 15, 5, '24 - 12 oz bottles', 18.72, 10, 22, 14, 0);
INSERT INTO "public"."products" ("product_id", "product_name", "supplier_id", "category_id", "quantity_per_unit", "unit_price", "units_in_stock", "units_on_order", "reorder_level", "discontinued") VALUES (41, 'Prosciutto Cotto', 8, 6, '20 - 1 kg packs', 94.82, 87, 42, 4, 0);
INSERT INTO "public"."products" ("product_id", "product_name", "supplier_id", "category_id", "quantity_per_unit", "unit_price", "units_in_stock", "units_on_order", "reorder_level", "discontinued") VALUES (42, 'Roast Turkey Slices', 1, 6, '48 - 6 oz jars', 41.30, 102, 22, 25, 0);
INSERT INTO "public"."products" ("product_id", "product_name", "supplier_id", "category_id", "quantity_per_unit", "unit_price", "units_in_stock", "units_on_order", "reorder_level", "discontinued") VALUES (43, 'Smoked Beef Pastrami', 2, 6, '10 boxes x 20 bags', 67.37, 28, 15, 9, 0);
INSERT INTO "public"."products" ("product_id", "product_name", "supplier_id", "category_id", "quantity_per_unit", "unit_price", "units_in_stock", "units_on_order", "reorder_level", "discontinued") VALUES (44, 'Chorizo Ibérico', 5, 6, '10 boxes x 20 bags', 94.84, 154, 49, 20, 0);
INSERT INTO "public"."products" ("product_id", "product_name", "supplier_id", "category_id", "quantity_per_unit", "unit_price", "units_in_stock", "units_on_order", "reorder_level", "discontinued") VALUES (45, 'Chicken Sausages', 14, 6, '36 boxes', 46.36, 33, 26, 28, 0);
INSERT INTO "public"."products" ("product_id", "product_name", "supplier_id", "category_id", "quantity_per_unit", "unit_price", "units_in_stock", "units_on_order", "reorder_level", "discontinued") VALUES (46, 'Beef Bresaola', 20, 6, '48 - 6 oz jars', 43.93, 176, 0, 25, 0);
INSERT INTO "public"."products" ("product_id", "product_name", "supplier_id", "category_id", "quantity_per_unit", "unit_price", "units_in_stock", "units_on_order", "reorder_level", "discontinued") VALUES (47, 'Turkey Ham', 17, 6, '10 boxes x 20 bags', 78.65, 20, 24, 23, 0);
INSERT INTO "public"."products" ("product_id", "product_name", "supplier_id", "category_id", "quantity_per_unit", "unit_price", "units_in_stock", "units_on_order", "reorder_level", "discontinued") VALUES (48, 'Salami Milano', 20, 6, '36 boxes', 55.03, 26, 46, 19, 0);
INSERT INTO "public"."products" ("product_id", "product_name", "supplier_id", "category_id", "quantity_per_unit", "unit_price", "units_in_stock", "units_on_order", "reorder_level", "discontinued") VALUES (49, 'Sun-Dried Tomatoes', 13, 7, '24 - 12 oz bottles', 25.43, 184, 22, 13, 1);
INSERT INTO "public"."products" ("product_id", "product_name", "supplier_id", "category_id", "quantity_per_unit", "unit_price", "units_in_stock", "units_on_order", "reorder_level", "discontinued") VALUES (50, 'Dried Apricots', 10, 7, '12 - 500 ml bottles', 48.31, 66, 46, 0, 0);
INSERT INTO "public"."products" ("product_id", "product_name", "supplier_id", "category_id", "quantity_per_unit", "unit_price", "units_in_stock", "units_on_order", "reorder_level", "discontinued") VALUES (51, 'Mixed Nuts', 7, 7, '36 boxes', 24.53, 34, 45, 19, 0);
INSERT INTO "public"."products" ("product_id", "product_name", "supplier_id", "category_id", "quantity_per_unit", "unit_price", "units_in_stock", "units_on_order", "reorder_level", "discontinued") VALUES (52, 'Medjool Dates', 9, 7, '24 - 12 oz bottles', 107.45, 18, 23, 1, 0);
INSERT INTO "public"."products" ("product_id", "product_name", "supplier_id", "category_id", "quantity_per_unit", "unit_price", "units_in_stock", "units_on_order", "reorder_level", "discontinued") VALUES (53, 'Roasted Pistachios', 12, 7, '12 - 500 ml bottles', 32.49, 23, 39, 8, 0);
INSERT INTO "public"."products" ("product_id", "product_name", "supplier_id", "category_id", "quantity_per_unit", "unit_price", "units_in_stock", "units_on_order", "reorder_level", "discontinued") VALUES (54, 'Dehydrated Mango', 18, 7, '24 - 12 oz bottles', 117.09, 84, 18, 25, 0);
INSERT INTO "public"."products" ("product_id", "product_name", "supplier_id", "category_id", "quantity_per_unit", "unit_price", "units_in_stock", "units_on_order", "reorder_level", "discontinued") VALUES (55, 'Fresh Blueberries', 15, 7, '20 - 1 kg packs', 3.63, 28, 39, 3, 1);
INSERT INTO "public"."products" ("product_id", "product_name", "supplier_id", "category_id", "quantity_per_unit", "unit_price", "units_in_stock", "units_on_order", "reorder_level", "discontinued") VALUES (56, 'Baby Spinach', 13, 7, '36 boxes', 113.33, 46, 8, 12, 0);
INSERT INTO "public"."products" ("product_id", "product_name", "supplier_id", "category_id", "quantity_per_unit", "unit_price", "units_in_stock", "units_on_order", "reorder_level", "discontinued") VALUES (57, 'Smoked Salmon', 14, 8, '20 - 1 kg packs', 31.08, 1, 26, 4, 0);
INSERT INTO "public"."products" ("product_id", "product_name", "supplier_id", "category_id", "quantity_per_unit", "unit_price", "units_in_stock", "units_on_order", "reorder_level", "discontinued") VALUES (58, 'Tuna in Olive Oil', 6, 8, '48 - 6 oz jars', 52.29, 199, 24, 26, 0);
INSERT INTO "public"."products" ("product_id", "product_name", "supplier_id", "category_id", "quantity_per_unit", "unit_price", "units_in_stock", "units_on_order", "reorder_level", "discontinued") VALUES (59, 'Sardines with Lemon', 3, 8, '10 boxes x 20 bags', 17.28, 145, 25, 8, 0);
INSERT INTO "public"."products" ("product_id", "product_name", "supplier_id", "category_id", "quantity_per_unit", "unit_price", "units_in_stock", "units_on_order", "reorder_level", "discontinued") VALUES (60, 'Anchovy Fillets', 18, 8, '20 - 1 kg packs', 105.38, 79, 38, 17, 0);
INSERT INTO "public"."products" ("product_id", "product_name", "supplier_id", "category_id", "quantity_per_unit", "unit_price", "units_in_stock", "units_on_order", "reorder_level", "discontinued") VALUES (61, 'Mussels in Escabeche', 1, 8, '12 - 500 ml bottles', 39.05, 51, 27, 6, 1);
INSERT INTO "public"."products" ("product_id", "product_name", "supplier_id", "category_id", "quantity_per_unit", "unit_price", "units_in_stock", "units_on_order", "reorder_level", "discontinued") VALUES (62, 'Octopus in Paprika Oil', 2, 8, '12 - 200 g jars', 10.68, 39, 10, 21, 0);
INSERT INTO "public"."products" ("product_id", "product_name", "supplier_id", "category_id", "quantity_per_unit", "unit_price", "units_in_stock", "units_on_order", "reorder_level", "discontinued") VALUES (63, 'Seaweed Salad', 18, 8, '20 - 1 kg packs', 108.01, 16, 28, 18, 0);
INSERT INTO "public"."products" ("product_id", "product_name", "supplier_id", "category_id", "quantity_per_unit", "unit_price", "units_in_stock", "units_on_order", "reorder_level", "discontinued") VALUES (64, 'Shrimp Cocktail', 13, 8, '12 - 200 g jars', 86.20, 93, 4, 30, 0);


--
-- Data for Name: regions; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO "public"."regions" ("region_id", "region_description") VALUES (1, 'Eastern');
INSERT INTO "public"."regions" ("region_id", "region_description") VALUES (2, 'Western');
INSERT INTO "public"."regions" ("region_id", "region_description") VALUES (3, 'Northern');
INSERT INTO "public"."regions" ("region_id", "region_description") VALUES (4, 'Southern');


--
-- Data for Name: shippers; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO "public"."shippers" ("shipper_id", "company_name", "phone") VALUES (1, 'SwiftShip Logistics', '+1 800-555-0111');
INSERT INTO "public"."shippers" ("shipper_id", "company_name", "phone") VALUES (2, 'Global Parcel Network', '+1 800-555-0122');
INSERT INTO "public"."shippers" ("shipper_id", "company_name", "phone") VALUES (3, 'Continental Freight Co.', '+1 800-555-0133');


--
-- Data for Name: suppliers; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO "public"."suppliers" ("supplier_id", "company_name", "contact_name", "country", "city", "phone", "address") VALUES (1, 'Andean Foods Ltd.', 'Noah Moreau', 'UK', 'Bristol', '+44 210-958-1625', '398 Lake Rd');
INSERT INTO "public"."suppliers" ("supplier_id", "company_name", "contact_name", "country", "city", "phone", "address") VALUES (2, 'Nordic Harvest AS', 'Ava Dubois', 'Norway', 'Oslo', '+47 674-441-5016', '177 Main St');
INSERT INTO "public"."suppliers" ("supplier_id", "company_name", "contact_name", "country", "city", "phone", "address") VALUES (3, 'Mediterraneo Import SRL', 'Valentina Bianchi', 'Mexico', 'CDMX', '+52 106-423-8345', '114 Main St');
INSERT INTO "public"."suppliers" ("supplier_id", "company_name", "contact_name", "country", "city", "phone", "address") VALUES (4, 'Côte & Co. Gourmets', 'Mateo Garcia', 'Germany', 'Hamburg', '+49 540-687-8813', '281 Industrial Pkwy');
INSERT INTO "public"."suppliers" ("supplier_id", "company_name", "contact_name", "country", "city", "phone", "address") VALUES (5, 'Iberia Fine Foods SA', 'Isabella Hernandez', 'UK', 'Bristol', '+44 311-940-9635', '588 Lake Rd');
INSERT INTO "public"."suppliers" ("supplier_id", "company_name", "contact_name", "country", "city", "phone", "address") VALUES (6, 'Alpine Dairies GmbH', 'Nicolas Bernard', 'USA', 'Boston', '+1 544-801-9823', '663 Industrial Pkwy');
INSERT INTO "public"."suppliers" ("supplier_id", "company_name", "contact_name", "country", "city", "phone", "address") VALUES (7, 'Atlantic Seafood BV', 'Benjamin Hernandez', 'Netherlands', 'Rotterdam', '+31 967-872-3973', '753 Main St');
INSERT INTO "public"."suppliers" ("supplier_id", "company_name", "contact_name", "country", "city", "phone", "address") VALUES (8, 'Maple Grove Traders', 'Ava Kowalski', 'Portugal', 'Porto', '+351 667-500-2200', '750 Industrial Pkwy');
INSERT INTO "public"."suppliers" ("supplier_id", "company_name", "contact_name", "country", "city", "phone", "address") VALUES (9, 'Prairie Grain Mills', 'Lucas Lopez', 'Finland', 'Espoo', '+358 190-951-6955', '23 Lake Rd');
INSERT INTO "public"."suppliers" ("supplier_id", "company_name", "contact_name", "country", "city", "phone", "address") VALUES (10, 'Rio Verde Exportações', 'Julia Hernandez', 'Argentina', 'Córdoba', '+54 943-161-5713', '516 Market Ave');
INSERT INTO "public"."suppliers" ("supplier_id", "company_name", "contact_name", "country", "city", "phone", "address") VALUES (11, 'Baltic Provisions Sp. z o.o.', 'Ava Dubois', 'Belgium', 'Antwerp', '+32 555-487-8557', '55 Main St');
INSERT INTO "public"."suppliers" ("supplier_id", "company_name", "contact_name", "country", "city", "phone", "address") VALUES (12, 'Cascadia Organics Inc.', 'Liam Garcia', 'Spain', 'Sevilla', '+34 918-460-5455', '987 Industrial Pkwy');
INSERT INTO "public"."suppliers" ("supplier_id", "company_name", "contact_name", "country", "city", "phone", "address") VALUES (13, 'Tyrol Delikatessen OG', 'Olivia Weber', 'Mexico', 'CDMX', '+52 622-463-2454', '94 Industrial Pkwy');
INSERT INTO "public"."suppliers" ("supplier_id", "company_name", "contact_name", "country", "city", "phone", "address") VALUES (14, 'Seine Select SAS', 'Daniel Smith', 'USA', 'Chicago', '+1 810-750-7622', '39 Lake Rd');
INSERT INTO "public"."suppliers" ("supplier_id", "company_name", "contact_name", "country", "city", "phone", "address") VALUES (15, 'Tuscan Pantry SRL', 'Emma Ribeiro', 'Canada', 'Vancouver', '+1 524-456-1389', '664 Market Ave');
INSERT INTO "public"."suppliers" ("supplier_id", "company_name", "contact_name", "country", "city", "phone", "address") VALUES (16, 'Lisboa Mercados Lda.', 'Alexander Lemaire', 'Mexico', 'CDMX', '+52 481-784-4849', '771 Main St');
INSERT INTO "public"."suppliers" ("supplier_id", "company_name", "contact_name", "country", "city", "phone", "address") VALUES (17, 'Lowlands Trading NL', 'Julia Schneider', 'UK', 'Leeds', '+44 771-890-5770', '804 Industrial Pkwy');
INSERT INTO "public"."suppliers" ("supplier_id", "company_name", "contact_name", "country", "city", "phone", "address") VALUES (18, 'Helvetia Foods AG', 'Julia Kowalski', 'Sweden', 'Stockholm', '+46 222-744-3732', '831 Industrial Pkwy');
INSERT INTO "public"."suppliers" ("supplier_id", "company_name", "contact_name", "country", "city", "phone", "address") VALUES (19, 'Danube Foods GmbH', 'Elena Dubois', 'Mexico', 'CDMX', '+52 784-121-6726', '470 Industrial Pkwy');
INSERT INTO "public"."suppliers" ("supplier_id", "company_name", "contact_name", "country", "city", "phone", "address") VALUES (20, 'Cantábrico Mar SA', 'Sara Garcia', 'Denmark', 'Aarhus', '+45 634-432-9467', '537 Market Ave');


--
-- Data for Name: territories; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO "public"."territories" ("territory_id", "territory_description", "region_id") VALUES (10000, 'Spain', 1);
INSERT INTO "public"."territories" ("territory_id", "territory_description", "region_id") VALUES (10001, 'Italy', 1);
INSERT INTO "public"."territories" ("territory_id", "territory_description", "region_id") VALUES (10002, 'Germany', 1);
INSERT INTO "public"."territories" ("territory_id", "territory_description", "region_id") VALUES (10003, 'Netherlands', 2);
INSERT INTO "public"."territories" ("territory_id", "territory_description", "region_id") VALUES (10004, 'Greece', 2);
INSERT INTO "public"."territories" ("territory_id", "territory_description", "region_id") VALUES (10005, 'France', 2);
INSERT INTO "public"."territories" ("territory_id", "territory_description", "region_id") VALUES (10006, 'Poland', 3);
INSERT INTO "public"."territories" ("territory_id", "territory_description", "region_id") VALUES (10007, 'Austria', 3);
INSERT INTO "public"."territories" ("territory_id", "territory_description", "region_id") VALUES (10008, 'Slovenia', 3);
INSERT INTO "public"."territories" ("territory_id", "territory_description", "region_id") VALUES (10009, 'Croatia', 4);
INSERT INTO "public"."territories" ("territory_id", "territory_description", "region_id") VALUES (10010, 'Estonia', 4);
INSERT INTO "public"."territories" ("territory_id", "territory_description", "region_id") VALUES (10011, 'Latvia', 4);


--
-- Name: categories categories_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."categories"
    ADD CONSTRAINT "categories_pkey" PRIMARY KEY ("category_id");


--
-- Name: customers customers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."customers"
    ADD CONSTRAINT "customers_pkey" PRIMARY KEY ("customer_id");


--
-- Name: employee_territories employee_territories_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."employee_territories"
    ADD CONSTRAINT "employee_territories_pkey" PRIMARY KEY ("employee_id", "territory_id");


--
-- Name: employees employees_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."employees"
    ADD CONSTRAINT "employees_pkey" PRIMARY KEY ("employee_id");


--
-- Name: order_details order_details_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."order_details"
    ADD CONSTRAINT "order_details_pkey" PRIMARY KEY ("order_id", "product_id");


--
-- Name: orders orders_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."orders"
    ADD CONSTRAINT "orders_pkey" PRIMARY KEY ("order_id");


--
-- Name: products products_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."products"
    ADD CONSTRAINT "products_pkey" PRIMARY KEY ("product_id");


--
-- Name: regions regions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."regions"
    ADD CONSTRAINT "regions_pkey" PRIMARY KEY ("region_id");


--
-- Name: shippers shippers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."shippers"
    ADD CONSTRAINT "shippers_pkey" PRIMARY KEY ("shipper_id");


--
-- Name: suppliers suppliers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."suppliers"
    ADD CONSTRAINT "suppliers_pkey" PRIMARY KEY ("supplier_id");


--
-- Name: territories territories_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."territories"
    ADD CONSTRAINT "territories_pkey" PRIMARY KEY ("territory_id");


--
-- Name: ix_order_details_product_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "ix_order_details_product_id" ON "public"."order_details" USING "btree" ("product_id");


--
-- Name: ix_orders_customer_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "ix_orders_customer_id" ON "public"."orders" USING "btree" ("customer_id");


--
-- Name: ix_orders_order_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "ix_orders_order_date" ON "public"."orders" USING "btree" ("order_date");


--
-- Name: employee_territories employee_territories_employeeid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."employee_territories"
    ADD CONSTRAINT "employee_territories_employeeid_fkey" FOREIGN KEY ("employee_id") REFERENCES "public"."employees"("employee_id");


--
-- Name: employee_territories employee_territories_territoryid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."employee_territories"
    ADD CONSTRAINT "employee_territories_territoryid_fkey" FOREIGN KEY ("territory_id") REFERENCES "public"."territories"("territory_id");


--
-- Name: employees employees_reportsto_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."employees"
    ADD CONSTRAINT "employees_reportsto_fkey" FOREIGN KEY ("reports_to") REFERENCES "public"."employees"("employee_id");


--
-- Name: order_details order_details_orderid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."order_details"
    ADD CONSTRAINT "order_details_orderid_fkey" FOREIGN KEY ("order_id") REFERENCES "public"."orders"("order_id");


--
-- Name: order_details order_details_productid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."order_details"
    ADD CONSTRAINT "order_details_productid_fkey" FOREIGN KEY ("product_id") REFERENCES "public"."products"("product_id");


--
-- Name: orders orders_customerid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."orders"
    ADD CONSTRAINT "orders_customerid_fkey" FOREIGN KEY ("customer_id") REFERENCES "public"."customers"("customer_id");


--
-- Name: orders orders_employeeid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."orders"
    ADD CONSTRAINT "orders_employeeid_fkey" FOREIGN KEY ("employee_id") REFERENCES "public"."employees"("employee_id");


--
-- Name: orders orders_shipvia_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."orders"
    ADD CONSTRAINT "orders_shipvia_fkey" FOREIGN KEY ("ship_via") REFERENCES "public"."shippers"("shipper_id");


--
-- Name: products products_categoryid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."products"
    ADD CONSTRAINT "products_categoryid_fkey" FOREIGN KEY ("category_id") REFERENCES "public"."categories"("category_id");


--
-- Name: products products_supplierid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."products"
    ADD CONSTRAINT "products_supplierid_fkey" FOREIGN KEY ("supplier_id") REFERENCES "public"."suppliers"("supplier_id");


--
-- Name: territories territories_regionid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."territories"
    ADD CONSTRAINT "territories_regionid_fkey" FOREIGN KEY ("region_id") REFERENCES "public"."regions"("region_id");


--
-- PostgreSQL database dump complete
--


